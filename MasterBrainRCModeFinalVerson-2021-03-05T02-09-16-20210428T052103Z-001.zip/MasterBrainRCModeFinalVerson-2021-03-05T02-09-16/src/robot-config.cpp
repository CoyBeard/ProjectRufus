#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
triport RightExpander = triport(PORT6);
triport LeftExpander = triport(PORT16);
/*vex-vision-config:begin*/
vision RightEye = vision (PORT7, 50);
/*vex-vision-config:end*/
inertial Gyro = inertial(PORT8);
/*vex-vision-config:begin*/
vision LeftEye = vision (PORT17, 50);
/*vex-vision-config:end*/
/*vex-vision-config:begin*/
vision FruntEye = vision (PORT18, 50);
/*vex-vision-config:end*/
bumper LeftButton = bumper(LeftExpander.H);
bumper RightButton = bumper(RightExpander.A);
sonar RightRangeFinder = sonar(RightExpander.G);
sonar FruntRangeFinder = sonar(RightExpander.C);
led LED1 = led(RightExpander.E);
led LED2 = led(RightExpander.F);
sonar LeftRangeFinder = sonar(LeftExpander.A);
sonar BackRangeFinder = sonar(LeftExpander.C);
led LED3 = led(LeftExpander.E);
led LED4 = led(LeftExpander.F);
controller Controller1 = controller(primary);
limit FruntLeftFootSwitch = limit(Brain.ThreeWirePort.A);
limit FruntRightFootSwitch = limit(Brain.ThreeWirePort.B);
limit BackLeftFootSwitch = limit(Brain.ThreeWirePort.C);
limit BackRightFootSwitch = limit(Brain.ThreeWirePort.D);

// VEXcode generated functions
// define variable for remote controller enable/disable
bool RemoteControlCodeEnabled = true;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}