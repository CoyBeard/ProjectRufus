/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Coy                                              */
/*    Created:      Thu Dec 24 2020                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// RightExpander        triport       6               
// RightEye             vision        7               
// Gyro                 inertial      8               
// LeftExpander         triport       16              
// LeftEye              vision        17              
// FruntEye             vision        18              
// LeftButton           bumper        H               
// RightButton          bumper        A               
// RightRangeFinder     sonar         G, H            
// FruntRangeFinder     sonar         C, D            
// LED1                 led           E               
// LED2                 led           F               
// LeftRangeFinder      sonar         A, B            
// BackRangeFinder      sonar         C, D            
// LED3                 led           E               
// LED4                 led           F               
// Controller1          controller                    
// FruntLeftFootSwitch  limit         A               
// FruntRightFootSwitch limit         B               
// BackLeftFootSwitch   limit         C               
// BackRightFootSwitch  limit         D               
// ---- END VEXCODE CONFIGURED DEVICES ----

/*----------------------------------------------------------------------------*/
/* Description: Example Manger VEXlink code */
/*----------------------------------------------------------------------------*/

#include "vex.h"

using namespace vex;

//GCode Vars:
int GCodeFinished = false;
int LeftMotorsEnabled = false;
int RightMotorsEnabled = false;

//EStop Vars
int RufusSleeping = false;
int EStopSent = false;

//trot vars 
//double StatonaryWalkInFoot = -3.5; // how far legs are place inward for standing walk 
double AddBallanceFootX = 0; // set by gyro adds to x for ballance
double AddBallanceFootY = 0; // set by gyro adds to y for ballance
double FLAddBallanceFootZ = 0; // set by gyro adds to y for ballance
double FRAddBallanceFootZ = 0; // set by gyro adds to y for ballance
double BLAddBallanceFootZ = 0; // set by gyro adds to y for ballance
double BRAddBallanceFootZ = 0; // set by gyro adds to y for ballance
double GyroSensitivity = 0.25; // determins how -much Rufus corrects his foot placement based off of the gyro 

// Controller vars
// STATIONARY MOVEMENT VARS
int Mode = 1;          // what mode Rufus is in
double LookSpeed = 30; // speed of looking

// Look left and right vars
double MaxLegLoookLARReach = 0;               // Set by algorithm, limits how far the legs will move in and out for safty reasons
double HipBendLimmit = 3;                     // in
double LookLeftAndRightCtrlSetPos = 0;        // use controller as potentiometer
double LookLeftAndRightCtrlSetPosINVERSE = 0; // inverse

// Look up and down
double MaxLookUpAndDownLegReach = 12;
double MaxLookUpAndDownLegSit = 7;
double LookUpAndDownControllerSetSitHeight = 0;
double LookUpAndDownControllerSetReachHeight = 0;

// Walk vars
double Height = 11;             // in
double StepClearanceHeight = 5; // in
double BackLeftStride = 0;      // in
double BackRightStride = 0;     // in
double FruntLeftStride = 0;     // in
double FruntRightStride = 0;    // in
double StrideAccuracy = 2;      // in
double MaxLegReach = 0;         // set by algorithm (in)
double ThighGearRatio = 5.5;    // gear ration of the hips
double KneeGearRatio = 5.5;     // gear ratio of the knees
double HipGearRatio = 5.5;      // gear ratio of the hips
double RdToDegree = 57.2958;    // multiplicant to convert radiant to degree
double ThighHomeOffset = 90;    // thigh home offset (degrees)
double KneeHomeOffset = 90;     // knee home offset (degrees)
double ts = 0;                  // thigh + shin length (in)
double HipSwayAmount = -1;      // inches
double HipSwayVelocity = 10;    // percent
double HipVelocity = 20;        // percent
double LegLengthHips = 0;       // length of leg when hip is moved
double StandHipOffset = 0;      // pos-facing in-  or  neg-facing out-, controles if "pigeon toed" (in)
int SetWalkDistance = 1000000;  // in
int WalkDistance = 0;           // how far Rufus has wlalked
double StridDistance = 1;       //distance of stride defalt to 1 set by remote 
double ShiftCenterOfGravityX = 0;//shift center of gravity x axis till balanced, set by ballance algrithms 
double ShiftCenterOfGravityY = 0;//shift center of gravity y axis till balanced, set by ballance algrithms 
double ShiftCenterOfGravitySencitivity = -0.15;//how much Rufus shifts his mass when he sees that one leeg has too much load (neg move mas away from struggling foot, pos moves towards), set here
double SumBallanceXPlus = 0; //universal sum of all factors a part of ballancing, set by gyro 
double SumBallanceYPlus = 0; //universal sum of all factors a part of ballancing, set by gyro 
double ShiftMassXLimmit = 1; //limit of shiftimg mass in x axis, set here 
double ShiftMassYLimmit = 1; //limit of shiftimg mass in y axis, set here 
double StepHeight = 2; //in height Rufus steps when trotting, walking, set here

// Trig vars
double BackLeftHipAngle = 0; // Motor degree of the hip
double BackRightHipAngle = 0;
double FruntLeftHipAngle = 0;
double FruntRightHipAngle = 0;
double FruntRightThighDegree = 0; // Motor degree of the thigh
double BackLeftThighDegree = 0;
double BackRightThighDegree = 0;
double FruntLeftThighDegree = 0;
double FruntRightKneeDegree = 0; // Motor degree of the knee
double FruntLeftKneeDegree = 0;
double BackRightKneeDegree = 0;
double BackLeftKneeDegree = 0;
double T = 6;    // thigh length
double S = 7.5;  // shin length
double x = 0;    // distance between foot and hip
double F = 7.29; // offset triangle
double b = 0;    // inner hip angle (h)
double y = 0;    // imaginary tryangle hypotenuse (FruntRightue)
double lf = 0;   // l + F
double a = 0;    // angle a

// Other vars
int e = 0; // counting var
int NA = 0; // Space filler for an unknown, always = 0 or NULL

// Instance of message link class
//left worker
vex::message_link LinkB(PORT20, "vex_robotics_team_1234_B", linkType::manager, true);

//right worker
vex::message_link LinkA(PORT10, "vex_robotics_team_1234_B", linkType::manager, true);

//recieved messages voids
void GCFinished_received( const char *message, const char *linkname, double value ) {
  printf("%s: was received on '%s' link\n", message, linkname );
  GCodeFinished = true;
}

void LeftMotorsEnabled_received( const char *message, const char *linkname, double value ) {
  printf("%s: was received on '%s' link\n", message, linkname );
  LeftMotorsEnabled = true;
  if (RightMotorsEnabled == true && LeftMotorsEnabled == true) {
    GCodeFinished = true;
  }
}

void RightMotorsEnabled_received( const char *message, const char *linkname, double value ) {
  printf("%s: was received on '%s' link\n", message, linkname );
  RightMotorsEnabled = true;
  if (RightMotorsEnabled == true && LeftMotorsEnabled == true) {
    GCodeFinished = true;
  }
}

void LeftHomeLegsFinished_received( const char *message, const char *linkname, double value ) {
  printf("%s: was received on '%s' link\n", message, linkname );

  //home right side
  LinkA.send("G4Legs");
}

void LeftKneesHomed_received( const char *message, const char *linkname, double value ) {
  printf("%s: was received on '%s' link\n", message, linkname );

  //home left side 
  LinkB.send("G4Legs");
}

//GCode voids
void G0 () {
  LinkB.send("G0");
  LinkA.send("G0");
}

void G1 (int l, double x, double y, double z, double v, int s, double t, double i, double b) {
  /*NOTES:
  l = which leg FL (1), FR (2), BL (3), BR (4), frunts (5), backs (6), lefts (7), rights (8), all(9), FL and BR(10), FR and BL(11)
  x = the hip axis (0 = straight up and down, neg = facing in from top view)
  y = the thigh axis (0 = straight up and down, neg = beckwards from top view)
  z = the height axis (0 = the origon of the hip (all the way up), neg is imposible, max height is depenent on the length of the leg)
  v = the velocity of all the motors on the chosen leg (0-100)
  s = stopping type (brake (1), coast (2), hold (3))
  t = the torque of all the motors on the chosen leg 
  i = invert right side 1 == true 0 == false
  b = invert back legs 1 == true 0 == false
  */
  LinkB.send("G1L", l);
  LinkB.send("G1X", x);
  LinkB.send("G1Y", y);
  LinkB.send("G1Z", z);
  LinkB.send("G1V", v);
  LinkB.send("G1S", s);
  LinkB.send("G1T", t);
  LinkB.send("G1I", i);
  LinkA.send("G1L", l);
  LinkA.send("G1X", x);
  LinkA.send("G1Y", y);
  LinkA.send("G1Z", z);
  LinkA.send("G1V", v);
  LinkA.send("G1S", s);
  LinkA.send("G1T", t);
  LinkA.send("G1I", i);
  LinkA.send("G1B", b);
  LinkB.send("G1B", b);
}

void G2() {
  LinkA.send("G2");
  LinkB.send("G2");
}

void G4 () {
    //home all knees
    LinkB.send("G4Knees");
    LinkA.send("G4Knees");
    //the rest is taken care of by recieved messages voids
}

void G5 () {
  LinkB.send("G5");
  LinkA.send("G5");
}

//other voids

//VOID (tests: unfunctional):
void SumBallanceVars () {
  //add gyro vars
  SumBallanceXPlus = AddBallanceFootX + ShiftCenterOfGravityX;
  SumBallanceYPlus = AddBallanceFootY + ShiftCenterOfGravityY;

  //limit ofset X
  if (SumBallanceXPlus > 2) {
    SumBallanceXPlus = 2;
  }
  if (SumBallanceXPlus < -2) {
    SumBallanceXPlus = -2;
  }

  //limit ofset Y
  if (SumBallanceYPlus > 2) {
    SumBallanceYPlus = 2;
  }
  if (SumBallanceYPlus < -2) {
    SumBallanceYPlus = -2;
  }
}

//VOID (tests: unfunctional):
void FindCenterOfGravity (int FootMode) {
  /*REFRENCE:
                           /\
                           |   (-X direction)
                           |
                       FL-------FR
                       |         |
  (+Y direction)  <--  |         |   -->  (-Y direction)
                       |         |
                       |         |
                       BL-------BR
                           |
                           |   (+X direction)
                           \/
  */

  //FL and BR UP
  if (FootMode == 10) {
    //Frunt Left faled to break ground
    if (FruntLeftFootSwitch.pressing() == true) {
      //shift mass away from FL
      ShiftCenterOfGravityX += ShiftCenterOfGravitySencitivity;
      ShiftCenterOfGravityY -= ShiftCenterOfGravitySencitivity;
    }
    //Back Right faled to break ground
    else if (BackRightFootSwitch.pressing() == true) {
      //shift mass away from BR
      ShiftCenterOfGravityX -= ShiftCenterOfGravitySencitivity;
      ShiftCenterOfGravityY += ShiftCenterOfGravitySencitivity;
    }
  }

  //FR and BL UP
  if (FootMode == 11) {
    //Frunt Right faled to break ground
    if (FruntRightFootSwitch.pressing() == true) {
      //shift mass away from FR
      ShiftCenterOfGravityX += ShiftCenterOfGravitySencitivity;
      ShiftCenterOfGravityY += ShiftCenterOfGravitySencitivity;
    }
    //Back Left faled to break ground
    else if (BackLeftFootSwitch.pressing() == true) {
      //shift mass away from BL
      ShiftCenterOfGravityX -= ShiftCenterOfGravitySencitivity;
      ShiftCenterOfGravityY -= ShiftCenterOfGravitySencitivity;
    }
  }

  //limit shift mass x
  if (ShiftCenterOfGravityX > ShiftMassXLimmit) {
    ShiftCenterOfGravityX = ShiftMassXLimmit;
  }
  if (ShiftCenterOfGravityX < (ShiftMassXLimmit * -1)) {
    ShiftCenterOfGravityX = (ShiftMassXLimmit * -1);
  }

  //limit shift mass y
  if (ShiftCenterOfGravityY > ShiftMassYLimmit) {
    ShiftCenterOfGravityY = ShiftMassYLimmit;
  }
  if (ShiftCenterOfGravityY < (ShiftMassYLimmit * -1)) {
    ShiftCenterOfGravityY = (ShiftMassYLimmit * -1);
  }

  //sum offsets
  SumBallanceVars();
}

void CalcBallanceXAndYs () {
/*REFRENCE:    (as Rufus is going "down" in that direction)
                              /\
                              |   (-Roll direction)
                              |
                          FL-------FR
                          |         |
 (+Pitch direction)  <--  |         |   -->  (-Pitch direction)
                          |         |
                          |         |
                          BL-------BR
                              |
                              |   (+Roll direction)
                              \/
*/

  AddBallanceFootX = Gyro.orientation(roll, degrees) * GyroSensitivity;
  AddBallanceFootY = Gyro.orientation(pitch, degrees) * GyroSensitivity;

  if (AddBallanceFootX > 2) {
    AddBallanceFootX = 2;
  }
  if (AddBallanceFootX < -2) {
    AddBallanceFootX = -2;
  }
  if (AddBallanceFootY > 2) {
    AddBallanceFootY = 2;
  }
  if (AddBallanceFootY < -2) {
    AddBallanceFootY = -2;
  }

  //sum offsets
  //SumBallanceVars();

  //BLAddBallanceFootZ = (sin(Gyro.orientation(pitch, degrees) + Gyro.orientation(roll, degrees))) * (7.1875);

}

void ShowLinkStatus() {
    //right worker (linkA)
    Brain.Screen.printAt(10, 100, true, "Link A (Right): %s",
                         LinkA.isLinked() ? "ok" : "--");

    //left worker (linkB)
    Brain.Screen.printAt(10, 50, true, "Link B (Left): %s",
                         LinkB.isLinked() ? "ok" : "--");

    Brain.Screen.printAt(10, 150, "Mode = %d", Mode);
}

void LookLeftAndRight(double Height, double BackRightS, double BackLeftS, double FruntRightS, double FruntLeftS) {
  //small dellay to prevent info overload 
  wait(0.1, seconds);

  LinkA.send("StationaryMovementModeX1",Controller1.Axis1.position());
  LinkA.send("StationaryMovementModeX2", Controller1.Axis2.position());
  LinkB.send("StationaryMovementModeX1", Controller1.Axis1.position());
  LinkB.send("StationaryMovementModeX2", Controller1.Axis2.position());
}

void Drive() {
  //small dellay to prevent info overload 
  wait(0.1, seconds);

  LinkA.send("Drive", Controller1.Axis3.position());
  LinkB.send("Drive", Controller1.Axis3.position());
}

void Stand(double BackRightS, double BackLeftS, double FruntRightS, double FruntLeftS) {
  if (Controller1.ButtonA.pressing() == false) { // stand
    //small dellay to prevent info overload 
    wait(0.1, seconds);

    // move to stand
    LinkA.send("StandMode", false);
    LinkB.send("StandMode", false);
  } else if (Controller1.ButtonA.pressing() == true) { // lie down
    //small dellay to prevent info overload 
    wait(0.1, seconds);

    // lie down
    LinkA.send("StandMode", true);
    LinkB.send("StandMode", true);
  }
}

void RCWalk() {
  // Walk IN PLACE
  while (Controller1.Axis1.position() == 0 && Controller1.Axis2.position() == 0) { 
    if (Controller1.ButtonA.pressing () == true) {
      Gyro.calibrate(); 
      wait(2.5, seconds);
    }
    //PLANT FEET
    //FL & BR
    CalcBallanceXAndYs();
    G1(10, 0 + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);
    //move alternate feet for ballance
    //FR & BL
    CalcBallanceXAndYs();
    G1(11, 0 + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //MOVE FEET UP
    //FL & BR
    G1(10, 0, 0, 12 - StepHeight, 100, 3, 100, 0, 0);
    //move alternate feet for ballance
    //FR & BL
    CalcBallanceXAndYs();
    G1(11, 0 + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);

    //present wait timing 
    wait(0.35, seconds);

    //Reed center of gravity offset
    //FindCenterOfGravity(10);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //PLANT FEET
    //FL & BR
    CalcBallanceXAndYs();
    G1(10, 0 + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);
    //move alternate feet for ballance
    //FR & BL
    CalcBallanceXAndYs();
    G1(11, 0 + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //present wait timing
    wait(0.2, seconds);

    //PLANT FEET
    //FR & BL
    CalcBallanceXAndYs();
    G1(11, 0 + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);
    //move alternate feet for ballance
    //FL & BR
    CalcBallanceXAndYs();
    G1(10, 0 + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //MOVE FEET UP
    //FR & BL
    CalcBallanceXAndYs();
    G1(11, 0, 0, 12 - StepHeight, 100, 3, 100, 0, 0);
    //move alternate feet for ballance
    //FL & BR
    CalcBallanceXAndYs();
    G1(10, 0 + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);

    //present wait timing
    wait(0.35, seconds);

    //Reed center of gravity offset
    //FindCenterOfGravity(11);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //PLANT FEET
    //FR & BL
    CalcBallanceXAndYs();
    G1(11, 0 + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);
    //move alternate feet for ballance
    //FL & BR
    CalcBallanceXAndYs();
    G1(10, 0 + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //present wait timing
    wait(0.2, seconds);
  }

  // Walk FORWARD 
  while (Controller1.Axis2.position() > 0) { 
    //Check for Estop
    waitUntil(RufusSleeping == false);

    //PLANT FEET
    //FL & BR
    CalcBallanceXAndYs();
    G1(10, StridDistance + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);
    //move alternate feet for ballance
    //FR & BL
    CalcBallanceXAndYs();
    G1(11, (StridDistance * -1) + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //present wait timing
    wait(0.35, seconds);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //MOVE FEET UP
    //FL & BR
    CalcBallanceXAndYs();
    G1(10, StridDistance * -1, 0, 10, 100, 3, 100, 0, 0);

    //MOVE FORWARD 
    //FR & BL
    CalcBallanceXAndYs();
    G1(11, StridDistance + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //present wait timing
    wait(0.35, seconds);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //PLANT FEET
    //FL & BR
    CalcBallanceXAndYs();
    G1(10, (StridDistance * -1) + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);
    //move alternate feet for ballance
    //FR & BL
    CalcBallanceXAndYs();
    G1(11, StridDistance + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //present wait timing
    wait(0.35, seconds);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //MOVE FEET UP
    //FR & BL
    CalcBallanceXAndYs();
    G1(11, (StridDistance * -1), 0, 10, 100, 3, 100, 0, 0);

    //MOVE FORWARD 
    //FL & BR
    CalcBallanceXAndYs();
    G1(10, StridDistance + AddBallanceFootX, 0 + AddBallanceFootY, 12, 20, 3, 100, 1, 0);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //present wait timing
    wait(0.35, seconds);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //PLANT FEET
    //FR & BL
    CalcBallanceXAndYs();
    G1(11, (StridDistance * -1) + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);
    //move alternate feet for ballance
    //FL & BR
    CalcBallanceXAndYs();
    G1(10, StridDistance + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);

    //Check for Estop
    waitUntil(RufusSleeping == false);
  }   


  /**  VOID (Tests: Unfunctional):
  // Walk BACKWARD 
  while (Controller1.Axis2.position() < 0) { 
    //Check for Estop
    waitUntil(RufusSleeping == false);

    //PLANT FEET
    //FL & BR
    CalcBallanceXAndYs();
    G1(10, (StridDistance * -1) + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);
    //move alternate feet for ballance
    //FR & BL
    CalcBallanceXAndYs();
    G1(11, StridDistance + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //present wait timing
    wait(0.35, seconds);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //MOVE FEET UP
    //FL & BR
    CalcBallanceXAndYs();
    G1(10, StridDistance, 0, 10, 100, 3, 100, 0, 0);

    //MOVE FORWARD 
    //FR & BL
    CalcBallanceXAndYs();
    G1(11, (StridDistance * -1) + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //present wait timing
    wait(0.35, seconds);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //PLANT FEET
    //FL & BR
    CalcBallanceXAndYs();
    G1(10, StridDistance + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);
    //move alternate feet for ballance
    //FR & BL
    CalcBallanceXAndYs();
    G1(11, (StridDistance * -1) + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //present wait timing
    wait(0.35, seconds);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //MOVE FEET UP
    //FR & BL
    CalcBallanceXAndYs();
    G1(11, StridDistance, 0, 10, 100, 3, 100, 0, 0);

    //MOVE FORWARD 
    //FL & BR
    CalcBallanceXAndYs();
    G1(10, (StridDistance * -1) + AddBallanceFootX, 0 + AddBallanceFootY, 12, 20, 3, 100, 1, 0);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //present wait timing
    wait(0.35, seconds);

    //Check for Estop
    waitUntil(RufusSleeping == false);

    //PLANT FEET
    //FR & BL
    CalcBallanceXAndYs();
    G1(11, StridDistance + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);
    //move alternate feet for ballance
    //FL & BR
    CalcBallanceXAndYs();
    G1(10, (StridDistance * -1) + AddBallanceFootX, 0 + AddBallanceFootY, 12, 100, 3, 100, 1, 0);

    //Check for Estop
    waitUntil(RufusSleeping == false);
  } 
  **/  
}


//EStop Thread
int Estop() { 
  while(1) {
    //EStop
    if ((LeftButton.pressing() == true || RightButton.pressing() == true) && EStopSent == false) {
      //sent EStop to workers
      G5();

      //sets "sleep mode" to stop the G Code
      RufusSleeping = true;

      //Toggle var to prevent repeated messages 
      EStopSent = true;

      //wait until buttons are decompressed
      waitUntil(LeftButton.pressing() == false && RightButton.pressing() == false);
    }

    //EStop Resume 
    if ((LeftButton.pressing() == true || RightButton.pressing() == true) && EStopSent == true) {
      //resumes G Code 
      RufusSleeping = false;

      //Toggle var to prevent repeated messages 
      EStopSent = false;

      //wait until buttons are decompressed
      waitUntil(LeftButton.pressing() == false && RightButton.pressing() == false);
    }

    //allow other tasks to run
    this_thread::sleep_for( 10 );
  }
}

//main thread
int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  //run constant EStop thread  
  vex::thread ut(Estop);

  /*
//-----------------------------------------------------------------------------------------------------------------------------//
//----------------------------------------------------REFRENCE NOTES-----------------------------------------------------------//


  GCODE COMMANDS:

  - G0(); - (Enables all motors, all axis brake and hold last position, sets GCodeFinished to true when completed)

  - G1(l, x, y, z, v, s, t, i, b); - (Move to point, sets GCodeFinished to true when completed)
  G1 NOTES:
  l = which leg FL (1), FR (2), BL (3), BR (4), frunts (5), backs (6), lefts (7), rights (8), all(9), FL and BR (10), FR and BL (11)
  x = the hip axis (0 = straight up and down, neg = facing in from top view)
  y = the thigh axis (0 = straight up and down, neg = beckwards from top view)
  z = the height axis (0 = the origon of the hip (all the way up), neg is imposible, max height is depenent on the length of the leg)
  v = the velocity of all the motors on the chosen leg (0-100)
  s = stopping type (brake (1), coast (2), hold (3))
  t = the torque of all the motors on the chosen leg 
  i = invert right side 1 == true 0 == false
  b = invert back legs 1 == true 0 == false

  - G2(); - (Move all axies to 0, sets GCodeFinished to true when completed)

  - G4(); - (Home all axies, sets GCodeFinished to true when completed)
  
  - G5(); - (Emergency stop, Cut all power to all motors, sets GCodeFinished to true when completed)

  - wait( X , seconds); - (Pauses GCode for X Seconds, DOES NOT set GCodeFinished to true when completed)


  USE IN BETWEEN BLOCKS:

  - waitUntil(GCodeFinished == true && RufusSleeping == false); GCodeFinished = false; (ONLY for any GCode commands that sets GCodeFinished to true when completed)

  - waitUntil(RufusSleeping == false); (ONLY after wait commands)


  OTHER NOTES:

  - Screen Size: 480(x) x 240(y)

  - Left side link is LinkB

  - Right side link is LinkA

  */

  //register callback
  LinkA.received( "GCFinished", GCFinished_received);
  LinkB.received( "GCFinished", GCFinished_received);
  LinkB.received( "LeftMotorsEnabled", LeftMotorsEnabled_received);
  LinkA.received( "RightMotorsEnabled", RightMotorsEnabled_received);
  LinkB.received( "LeftHomeKneesFinished", LeftKneesHomed_received);
  LinkB.received( "LeftHomeLegsFinished", LeftHomeLegsFinished_received);

  //Display Link Status
  ShowLinkStatus();

  //wait for link connections 
  waitUntil(LinkA.isLinked());
  waitUntil(LinkB.isLinked());

  //Display Link Status
  ShowLinkStatus();

  //dellay to assure connections are sinked 
  wait(2, seconds);

  //main loop
  while (RufusSleeping == false) {
    //Display Link Status
    ShowLinkStatus();

/*
    MODE KEY:
    1 == Stand / LieDown
    2 == StationaryMovement
    3 == Move all axies to 0
    4 == Walk
    5 == EStop 
    6 == home all axies 
    */

    //sences when buttons pressed 
    if (Controller1.ButtonL1.pressing() == true) {
      Mode = 1;
    }

    if (Controller1.ButtonR1.pressing() == true) {
      Mode = 2;
    }

    if (Controller1.ButtonR2.pressing() == true) {
      Mode = 3;
    }

    if (Controller1.ButtonL2.pressing() == true) {
      Mode = 4;
    }

    if (Controller1.ButtonY.pressing() == true) {
      Mode = 5;
    }

    if (Controller1.ButtonX.pressing() == true) {
      Mode = 6;
    }

    if (Controller1.ButtonB.pressing() == true) {
      Mode = 7;
    }


    //difrent modes 
    if (Mode == 1) { // Stand / LieDown
      Drive();
      
      Stand(0, 0, 0, 0);
    }

    if (Mode == 2) { // StationaryMovement
      Drive();

      LookLeftAndRight(Height, 0, 0, 0, 0);
    }

    if (Mode == 3) { // Move all axies to 0 (G2)
      G2();
    }

    if (Mode == 4) { // Walk
      //wait for vexlink 
      wait(2, seconds);

      RCWalk();
    }

    if (Mode == 5) {// EStop
      G5();
    }

    if (Mode == 6) {// Home all axies 
      G4();

      //wait untill g4 is done 
      waitUntil(GCodeFinished == true); GCodeFinished = false;

      //set to stand mode to prevent loop
      Mode = 1;
    }

    if (Mode == 7) {// Enable all motors 
      G0();
    }

  }

  // Allow other tasks to run
  this_thread::sleep_for(50);
}
