using namespace vex;

extern brain Brain;

using signature = vision::signature;

// VEXcode devices
extern triport RightExpander;
extern signature RightEye__SIG_1;
extern signature RightEye__SIG_2;
extern signature RightEye__SIG_3;
extern signature RightEye__SIG_4;
extern signature RightEye__SIG_5;
extern signature RightEye__SIG_6;
extern signature RightEye__SIG_7;
extern vision RightEye;
extern inertial Gyro;
extern triport LeftExpander;
extern signature LeftEye__SIG_1;
extern signature LeftEye__SIG_2;
extern signature LeftEye__SIG_3;
extern signature LeftEye__SIG_4;
extern signature LeftEye__SIG_5;
extern signature LeftEye__SIG_6;
extern signature LeftEye__SIG_7;
extern vision LeftEye;
extern signature FruntEye__SIG_1;
extern signature FruntEye__SIG_2;
extern signature FruntEye__SIG_3;
extern signature FruntEye__SIG_4;
extern signature FruntEye__SIG_5;
extern signature FruntEye__SIG_6;
extern signature FruntEye__SIG_7;
extern vision FruntEye;
extern bumper LeftButton;
extern bumper RightButton;
extern sonar RightRangeFinder;
extern sonar FruntRangeFinder;
extern led LED1;
extern led LED2;
extern sonar LeftRangeFinder;
extern sonar BackRangeFinder;
extern led LED3;
extern led LED4;
extern controller Controller1;
extern limit FruntLeftFootSwitch;
extern limit FruntRightFootSwitch;
extern limit BackLeftFootSwitch;
extern limit BackRightFootSwitch;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );