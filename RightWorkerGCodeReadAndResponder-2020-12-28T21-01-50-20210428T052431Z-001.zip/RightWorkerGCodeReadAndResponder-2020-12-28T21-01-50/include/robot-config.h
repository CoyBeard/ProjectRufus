using namespace vex;

extern brain Brain;

// VEXcode devices
extern motor BRHip;
extern motor BRThigh;
extern motor BRKnee1;
extern motor BRKnee2;
extern motor FRHip;
extern motor FRThigh;
extern motor FRKnee1;
extern motor FRKnee2;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );