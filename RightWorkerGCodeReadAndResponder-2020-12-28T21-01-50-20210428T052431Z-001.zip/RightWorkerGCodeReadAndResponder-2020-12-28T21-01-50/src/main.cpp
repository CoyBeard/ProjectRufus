/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Coy                                              */
/*    Created:      Thu Dec 24 2020                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// BRHip                motor         1               
// BRThigh              motor         2               
// BRKnee1              motor         3               
// BRKnee2              motor         4               
// FRHip                motor         16              
// FRThigh              motor         17              
// FRKnee1              motor         18              
// FRKnee2              motor         19              
// ---- END VEXCODE CONFIGURED DEVICES ----

/*----------------------------------------------------------------------------*/
/* Description: Example Worker VEXlink code */
/*----------------------------------------------------------------------------*/
#include "vex.h"

using namespace vex;

// Instance of message link class
//Master Link
vex::message_link LinkA(PORT20, "vex_robotics_team_1234_B", linkType::worker, true);

//Union Link
vex::message_link LinkC(PORT10, "vex_robotics_team_1234_C", linkType::manager, true);

//GCode Vars
int ActiveLegs = 0;
double FootXPos = 0;
double FootYPos = 0;
double FootZPos = 0;
double JointSpeed = 0;
int StopType = 0;
double JointTorque = 0;
double InvertRightSide = 0;
double InvertBackLegs = 0;
int BLFinished = false;
int FLFinished = false;
int GCodeFinished = false;

//stationary movement vars
int CTRLAxis1INTRecieved = 0;
int CTRLAxis2INTRecieved = 0;

//home vars
int SetAllZerosCalculated = false;

//pos calcs vars
// Trig vars
double BackLeftHipDegree = 0; // Motor degree of the hip
double BackRightHipDegree = 0;
double FruntLeftHipDegree = 0;
double FruntRightHipDegree = 0;
double FruntRightThighDegree = 0; // Motor degree of the thigh
double BackLeftThighDegree = 0;
double BackRightThighDegree = 0;
double FruntLeftThighDegree = 0;
double FruntRightKneeDegree = 0; // Motor degree of the knee
double FruntLeftKneeDegree = 0;
double BackRightKneeDegree = 0;
double BackLeftKneeDegree = 0;
double T = 6;    // thigh length
double S = 7.5;  // shin length
double x = 0;    // distance between foot and hip
double F = 7.29; // offset triangle
double b = 0;    // inner hip angle (h)
double y = 0;    // imaginary tryangle hypotenuse (FruntRightue)
double lf = 0;   // l + F
double a = 0;    // angle a

// Controller vars
// STATIONARY MOVEMENT VARS
int Mode = 1;          // what mode Rufus is in
double LookSpeed = 30; // speed of looking

// Look left and right vars
double MaxLegLoookLARReach = 0;               // Set by algorithm, limits how far the legs will move in and out for safty reasons
double HipBendLimmit = 3;                     // in
double LookLeftAndRightCtrlSetPos = 0;        // use controller as potentiometer
double LookLeftAndRightCtrlSetPosINVERSE = 0; // inverse

// Look up and down
double MaxLookUpAndDownLegReach = 12;
double MaxLookUpAndDownLegSit = 7;
double LookUpAndDownControllerSetSitHeight = 0;
double LookUpAndDownControllerSetReachHeight = 0;

// Walk vars
double Height = 11;             // in
double StepClearanceHeight = 5; // in
double BackLeftStride = 0;      // in
double BackRightStride = 0;     // in
double FruntLeftStride = 0;     // in
double FruntRightStride = 0;    // in
double StrideAccuracy = 2;      // in
double MaxLegReach = 0;         // set by algorithm (in)
double ThighGearRatio = 5.5;    // gear ration of the hips
double KneeGearRatio = 5.5;     // gear ratio of the knees
double HipGearRatio = 5.5;      // gear ratio of the hips
double RdToDegree = 57.2958;    // multiplicant to convert radiant to degree
double ThighHomeOffset = 90;    // thigh home offset (degrees)
double KneeHomeOffset = 90;     // knee home offset (degrees)
double ts = 0;                  // thigh + shin length (in)
//double HipSwayAmount = -1;      // inches
//double HipSwayVelocity = 10;    // percent
//double HipVelocity = 20;        // percent
double LegLengthHips = 0;       // length of leg when hip is moved
double StandHipOffset = 0;      // pos-facing in-  or  neg-facing out-, controles if "pigeon toed" (in)
//int Estop = false;              // Emergency Stop
//int SetWalkDistance = 1000000;  // in
//int WalkDistance = 0;           // how far Rufus has wlalked

// Homing vars
int HomingLegCount = 1;       // Homing sequence counter
int HipHomingVelocity = 60;   // Hips Homing speed
int ThighHomingVelocity = 50; // Thighs Homing speed
int KneeHomingVelocity = 80;  // Knees Homing speed

// Sencorless homing Sensitivitys (Torque)
double FRKHomingPeakTorque = 0.5; // Nm
double BRKHomingPeakTorque = 0.5; // Hip Abs Max = 0.90 Nm
double FRTHomingPeakTorque = 0.75; // Thigh Abs Max = 0.91 Nm
double BRTHomingPeakTorque = 0.75; // Knee Abs Max = 1.81 Nm
double FRHHomingPeakTorque = 0.75;
double BRHHomingPeakTorque = 0.75;

void FRLegPos(double h, double l, double B) {
  T = 7;     // thigh length
  S = 5.375; // shin length
  x = 0;     // distance between foot and hip
  F = 7.29;  // offset triangle
  b = 0;     // inner hip angle (h)
  y = 0;     // imaginary tryangle hypotenuse (FruntRightue)
  lf = 0;    // l + F
  a = 0;     // a plus h = H

  // hip angle
  LegLengthHips = sqrt((B * B) + (h * h));

  FruntRightHipDegree =
      (acos(((LegLengthHips * LegLengthHips) + (h * h) - (B * B)) /
            (2 * LegLengthHips * h))) *
      RdToDegree;

  if (B < 0) {
    FruntRightHipDegree *= -1;
  }

  // leg angle
  x = sqrt((h * h) + (l * l));

  b = acos(((x * x) + (T * T) - (S * S)) / (2 * x * T));

  lf = l + F;

  y = sqrt(((h * h) + (lf * lf)));

  a = acos(((x * x) + (F * F) - (y * y)) / (2 * x * F));

  FruntRightThighDegree =
      ((acos(((x * x) + (T * T) - (S * S)) / (2 * T * x))) + a) * RdToDegree *
      ThighGearRatio;

  FruntRightKneeDegree = ((acos(((S * S) + (T * T) - (x * x)) / (2 * T * S))) *
                         RdToDegree * -1 * KneeGearRatio);

  FruntRightThighDegree =
      FruntRightThighDegree - (ThighHomeOffset * ThighGearRatio);

  FruntRightKneeDegree = FruntRightKneeDegree + (KneeHomeOffset * KneeGearRatio);

  FruntRightHipDegree = FruntRightHipDegree * ThighGearRatio;
}

void BRLegPos(double h, double l, double B) {
  T = 7;     // thigh length
  S = 5.375; // shin length
  x = 0;     // distance between foot and hip
  F = 7.29;  // offset triangle
  b = 0;     // inner hip angle (h)
  y = 0;     // imaginary tryangle hypotenuse (BackRightue)
  lf = 0;    // l + F
  a = 0;     // a plus h = H

  // hip angle
  LegLengthHips = sqrt((B * B) + (h * h));

  BackRightHipDegree =
      (acos(((LegLengthHips * LegLengthHips) + (h * h) - (B * B)) /
            (2 * LegLengthHips * h))) *
      RdToDegree;

  if (B < 0) {
    BackRightHipDegree *= -1;
  }

  // leg angle
  x = sqrt((h * h) + (l * l));

  b = acos(((x * x) + (T * T) - (S * S)) / (2 * x * T));

  lf = l + F;

  y = sqrt(((h * h) + (lf * lf)));

  a = acos(((x * x) + (F * F) - (y * y)) / (2 * x * F));

  BackRightThighDegree =
      ((acos(((x * x) + (T * T) - (S * S)) / (2 * T * x))) + a) * RdToDegree *
      ThighGearRatio;

  BackRightKneeDegree = ((acos(((S * S) + (T * T) - (x * x)) / (2 * T * S))) *
                         RdToDegree * -1 * KneeGearRatio);

  BackRightThighDegree =
      BackRightThighDegree - (ThighHomeOffset * ThighGearRatio);

  BackRightKneeDegree = BackRightKneeDegree + (KneeHomeOffset * KneeGearRatio);

  BackRightHipDegree = BackRightHipDegree * ThighGearRatio;
}

void printMotorValues(int Temp, int Torque, int Power, int Current, int Voltage, int Position) {
  if (Temp == true) {
    printf("BackRightE Motor Temp percent: %i\n", int(BRHip.temperature()));
    printf("FruntRightE Motor Temp percent: %i\n", int(FRHip.temperature()));
    printf("BackRightL Motor Temp percent: %i\n", int(BRThigh.temperature()));
    printf("FruntRightL Motor Temp percent: %i\n", int(FRThigh.temperature()));
    printf("BackRightK Motor Temp percent: %i\n", int(BRKnee1.temperature()));
    printf("FruntRightK Motor Temp percent: %i\n", int(FRKnee1.temperature()));
  }
  if (Torque == true) {
    printf("BackRightE Motor Torque Nm (*100): %i\n", int(100 * BRHip.torque()));
    printf("FruntRightE Motor Torque Nm (*100): %i\n",
           int(100 * FRHip.torque()));
    printf("BackRightL Motor Torque Nm (*100): %i\n",
           int(100 * BRThigh.torque()));
    printf("FruntRightL Motor Torque Nm (*100): %i\n",
           int(100 * FRThigh.torque()));
    printf("BackRightK Motor Torque Nm (*100): %i\n",
           int(100 * BRKnee1.torque()));
    printf("FruntRightK Motor Torque Nm (*100): %i\n",
           int(100 * FRKnee1.torque()));
  }
  if (Power == true) {
    printf("BackRightE Motor Power watts (*100): %i\n",
           int(100 * BRHip.power()));
    printf("FruntRightE Motor Power watts (*100): %i\n",
           int(100 * FRHip.power()));
    printf("BackRightL Motor Power watts (*100): %i\n",
           int(100 * BRThigh.power()));
    printf("FruntRightL Motor Power watts (*100): %i\n",
           int(100 * FRThigh.power()));
    printf("BackRightK Motor Power watts (*100): %i\n",
           int(100 * BRKnee1.power()));
    printf("FruntRightK Motor Power watts (*100): %i\n",
           int(100 * FRKnee1.power()));
  }
  if (Current == true) {
    printf("BackRightE Motor Current amps (*100): %i\n",
           int(100 * BRHip.current()));
    printf("FruntRightE Motor Current amps (*100): %i\n",
           int(100 * FRHip.current()));
    printf("BackRightL Motor Current amps (*100): %i\n",
           int(100 * BRThigh.current()));
    printf("FruntRightL Motor Current amps (*100): %i\n",
           int(100 * FRThigh.current()));
    printf("BackRightK Motor Current amps (*100): %i\n",
           int(100 * BRKnee1.current()));
    printf("FruntRightK Motor Current amps (*100): %i\n",
           int(100 * FRKnee1.current()));
  }
  if (Voltage == true) {
    printf("BackRightE Motor Volts (*100): %i\n",
           int(100 * BRHip.power() - BRHip.current()));
    printf("FruntRightE Motor Volts (*100): %i\n",
           int(100 * FRHip.power() - FRHip.current()));
    printf("BackRightL Motor Volts (*100): %i\n",
           int(100 * BRThigh.power() - BRThigh.current()));
    printf("FruntRightL Motor Volts (*100): %i\n",
           int(100 * FRThigh.power() - FRThigh.current()));
    printf("BackRightK Motor Volts (*100): %i\n",
           int(100 * BRKnee1.power() - BRKnee1.current()));
    printf("FruntRightK Motor Volts (*100): %i\n",
           int(100 * FRKnee1.power() - FRKnee1.current()));
  }
  if (Position) {
    printf("BackRightE Motor Position deg: %i\n", int(BRHip.position(degrees)));
    printf("FruntRightE Motor Position deg: %i\n", int(FRHip.position(degrees)));
    printf("BackRightL Motor Position deg: %i\n",
           int(BRThigh.position(degrees)));
    printf("FruntRightL Motor Position deg: %i\n",
           int(FRThigh.position(degrees)));
    printf("BackRightK Motor Position deg: %i\n", int(BRKnee1.position(degrees)));
    printf("FruntRightK Motor Position deg: %i\n",
           int(FRKnee1.position(degrees)));

  }
}

void EStop () {
  FRHip.setVelocity(0, percent); 
  FRThigh.setVelocity(0, percent); 
  FRKnee1.setVelocity(0, percent); 
  FRKnee2.setVelocity(0, percent); 
  BRHip.setVelocity(0, percent); 
  BRThigh.setVelocity(0, percent); 
  BRKnee1.setVelocity(0, percent); 
  BRKnee2.setVelocity(0, percent); 
  FRHip.setMaxTorque(0, percent); 
  FRThigh.setMaxTorque(0, percent); 
  FRKnee1.setMaxTorque(0, percent); 
  FRKnee2.setMaxTorque(0, percent); 
  BRHip.setMaxTorque(0, percent); 
  BRThigh.setMaxTorque(0, percent); 
  BRKnee1.setMaxTorque(0, percent); 
  BRKnee2.setMaxTorque(0, percent); 
  BRHip.setStopping(coast);
  BRThigh.setStopping(coast);
  BRKnee1.setStopping(coast);
  BRKnee2.setStopping(coast);
  FRHip.setStopping(coast);
  FRThigh.setStopping(coast);
  FRKnee1.setStopping(coast);
  FRKnee2.setStopping(coast);
  FRHip.spinTo(0,degrees, false); 
  FRThigh.spinTo(0,degrees, false); 
  FRKnee1.spinTo(0,degrees, false); 
  FRKnee2.spinTo(0,degrees, false); 
  BRHip.spinTo(0,degrees, false); 
  BRThigh.spinTo(0,degrees, false); 
  BRKnee1.spinTo(0,degrees, false); 
  BRKnee2.spinTo(0,degrees, false);
  FRHip.stop(); 
  FRThigh.stop(); 
  FRKnee1.stop(); 
  FRKnee2.stop(); 
  BRHip.stop(); 
  BRThigh.stop(); 
  BRKnee1.stop(); 
  BRKnee2.stop();
  //LinkA.send("GCFinished");
}

void SetAllZeros() {
  if (SetAllZerosCalculated == false) {
    BRHip.setPosition(0, degrees); 
    BRThigh.setPosition(0, degrees); 
    BRKnee1.setPosition(0, degrees); 
    BRKnee2.setPosition(0, degrees); 
    FRHip.setPosition(0, degrees); 
    FRThigh.setPosition(0, degrees); 
    FRKnee1.setPosition(0, degrees); 
    FRKnee2.setPosition(0, degrees); 
    SetAllZerosCalculated = true;
  }
}

//react 
void FLLegFinished() {
  FLFinished = true;
}
//read
void FLLegFinished_Recieved(const char *message, const char *linkname, double t) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         t);
  FLLegFinished();
}

//react 
void BLLegFinished() {
  BLFinished = true;
}
//read
void BLLegFinished_Recieved(const char *message, const char *linkname, double t) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         t);
  BLLegFinished();
}

//-------------------------------------------------------------------------//
//--------------------------------G0---------------------------------------//

//react GCode
void G0 () {
  //set velocity
    FRHip.setVelocity(100, percent); 
    FRThigh.setVelocity(100, percent); 
    FRKnee1.setVelocity(100, percent); 
    FRKnee2.setVelocity(100, percent); 
    BRHip.setVelocity(100, percent); 
    BRThigh.setVelocity(100, percent); 
    BRKnee1.setVelocity(100, percent); 
    BRKnee2.setVelocity(100, percent); 

    //set torque
    FRHip.setMaxTorque(100, percent); 
    FRThigh.setMaxTorque(100, percent); 
    FRKnee1.setMaxTorque(100, percent); 
    FRKnee2.setMaxTorque(100, percent); 
    BRHip.setMaxTorque(100, percent); 
    BRThigh.setMaxTorque(100, percent); 
    BRKnee1.setMaxTorque(100, percent); 
    BRKnee2.setMaxTorque(100, percent); 

    //set brake
    FRHip.setStopping(hold); 
    FRThigh.setStopping(hold); 
    FRKnee1.setStopping(hold); 
    FRKnee2.setStopping(hold); 
    BRHip.setStopping(hold); 
    BRThigh.setStopping(hold); 
    BRKnee1.setStopping(hold); 
    BRKnee2.setStopping(hold); 

    //exicute motor movement 
    FRHip.spinFor(1, degrees, false); 
    FRThigh.spinFor(1, degrees, false); 
    FRKnee1.spinFor(1, degrees, false); 
    FRKnee2.spinFor(1, degrees, false); 
    BRHip.spinFor(1, degrees, false); 
    BRThigh.spinFor(1, degrees, false); 
    BRKnee1.spinFor(1, degrees, false); 
    BRKnee2.spinFor(1, degrees, false);

    //feedback
    LinkA.send("RightMotorsEnabled");
}
//read GCode
void G0Enable(const char *message, const char *linkname, double t) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         t);
  G0();
}

//-------------------------------------------------------------------------//
//--------------------------------G1---------------------------------------//

//react GCode
void G1(int l, double x, double y, double z, double v, int s, double t, int i, int b) {
  if (l == 2 || l == 5 || l == 8 || l == 9 || l == 11) {// FR
    //set velocity
    FRHip.setVelocity(v, percent); 
    FRThigh.setVelocity(v, percent); 
    FRKnee1.setVelocity(v, percent); 
    FRKnee2.setVelocity(v, percent); 

    //set torque
    FRHip.setMaxTorque(t, percent); 
    FRThigh.setMaxTorque(t, percent); 
    FRKnee1.setMaxTorque(t, percent); 
    FRKnee2.setMaxTorque(t, percent); 

    //set stopping type
    if (s == 1) {
      FRHip.setStopping(brake); 
      FRThigh.setStopping(brake); 
      FRKnee1.setStopping(brake); 
      FRKnee2.setStopping(brake); 
    }
    if (s == 2) {
      FRHip.setStopping(coast); 
      FRThigh.setStopping(coast); 
      FRKnee1.setStopping(coast); 
      FRKnee2.setStopping(coast); 
    }
    if (s == 3) {
      FRHip.setStopping(hold); 
      FRThigh.setStopping(hold); 
      FRKnee1.setStopping(hold); 
      FRKnee2.setStopping(hold); 
    }

    //calc motor degrees
    if (i == 0) {
      FRLegPos(z, x, y);
    }
    if (i == 1) {
      FRLegPos(z, x, (y * -1));
    }
    
    //exicute motor movement 
    FRHip.spinToPosition(FruntRightHipDegree, degrees, false); 
    FRThigh.spinToPosition(FruntRightThighDegree, degrees, false); 
    FRKnee1.spinToPosition(FruntRightKneeDegree, degrees, false); 
    FRKnee2.spinToPosition(FruntRightKneeDegree, degrees, false); 

    /*
    //send GCF cases
    if (l == 2) { 
      //send finished message
      waitUntil(FRHip.isDone() && FRThigh.isDone() && FRKnee1.isDone() && FRKnee2.isDone());
      LinkA.send("GCFinished");
    }
    if (l == 5) { 
      //send finished message
      waitUntil(FRHip.isDone() && FRThigh.isDone() && FRKnee1.isDone() && FRKnee2.isDone() && FLFinished == true);
      FLFinished = false;
      LinkA.send("GCFinished");
    }
    if (l == 11) { 
      //send finished message
      waitUntil(FRHip.isDone() && FRThigh.isDone() && FRKnee1.isDone() && FRKnee2.isDone() && BLFinished == true);
      BLFinished = false;
      LinkA.send("GCFinished");
    }
    */
  }

  if (l == 4 || l == 6 || l == 8 || l == 9 || l == 10) {// BR
    //set velocity
    BRHip.setVelocity(v, percent); 
    BRThigh.setVelocity(v, percent); 
    BRKnee1.setVelocity(v, percent); 
    BRKnee2.setVelocity(v, percent); 

    //set torque
    BRHip.setMaxTorque(t, percent); 
    BRThigh.setMaxTorque(t, percent); 
    BRKnee1.setMaxTorque(t, percent); 
    BRKnee2.setMaxTorque(t, percent); 

    //set stopping type
    if (s == 1) {
      BRHip.setStopping(brake); 
      BRThigh.setStopping(brake); 
      BRKnee1.setStopping(brake); 
      BRKnee2.setStopping(brake); 
    }
    if (s == 2) {
      BRHip.setStopping(coast); 
      BRThigh.setStopping(coast); 
      BRKnee1.setStopping(coast); 
      BRKnee2.setStopping(coast); 
    }
    if (s == 3) {
      BRHip.setStopping(hold); 
      BRThigh.setStopping(hold); 
      BRKnee1.setStopping(hold); 
      BRKnee2.setStopping(hold); 
    }

    //calc motor degrees
    if (i == 0 && b == 0) {
      BRLegPos(z, x, y);
    }
    if (i == 1 && b == 0) {
      BRLegPos(z, x, (y * -1));
    }
    if (i == 0 && b == 1) {
      BRLegPos(z, (x * -1), y);
    }
    if (i == 1 && b == 1) {
      BRLegPos(z, (x * -1), (y * -1));
    }
    
    //exicute motor movement 
    BRHip.spinToPosition(BackRightHipDegree, degrees, false); 
    BRThigh.spinToPosition(BackRightThighDegree, degrees, false); 
    BRKnee1.spinToPosition(BackRightKneeDegree, degrees, false); 
    BRKnee2.spinToPosition(BackRightKneeDegree, degrees, false);

    /*
    //send GCF cases
    if (l == 4) {  
      //send finished message
      waitUntil(BRHip.isDone() && BRThigh.isDone() && BRKnee1.isDone() && BRKnee2.isDone());
      LinkA.send("GCFinished");
    }
    if (l == 8) {  
      //send finished message
      waitUntil(BRHip.isDone() && BRThigh.isDone() && BRKnee1.isDone() && BRKnee2.isDone() && FRHip.isDone() && FRThigh.isDone() && FRKnee1.isDone() && FRKnee2.isDone());
      LinkA.send("GCFinished");
    }
    if (l == 6) {  
      //send finished message
      waitUntil(BRHip.isDone() && BRThigh.isDone() && BRKnee1.isDone() && BRKnee2.isDone() && BLFinished == true);
      BLFinished = false;
      LinkA.send("GCFinished");
    }
    if (l == 10) {  
      //send finished message
      waitUntil(BRHip.isDone() && BRThigh.isDone() && BRKnee1.isDone() && BRKnee2.isDone() && FLFinished == true);
      FLFinished = false;
      LinkA.send("GCFinished");
    }
    if (l == 9) {  
      //send finished message
      waitUntil(BRHip.isDone() && BRThigh.isDone() && BRKnee1.isDone() && BRKnee2.isDone() && FRHip.isDone() && FRThigh.isDone() && FRKnee1.isDone() && FRKnee2.isDone() && FLFinished == true && BLFinished == true);
      BLFinished = false;
      FLFinished = false;
      LinkA.send("GCFinished");
    }
    */
  }
}
//read GCode
void G1L(const char *message, const char *linkname, double l) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         l);
  ActiveLegs = l;
}
void G1X(const char *message, const char *linkname, double x) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         x);
  FootXPos = x;
}
void G1Y(const char *message, const char *linkname, double y) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         y);
  FootYPos = y;
}
void G1Z(const char *message, const char *linkname, double z) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         z);
  FootZPos = z;
}
void G1V(const char *message, const char *linkname, double v) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         v);
  JointSpeed = v;
}
void G1S(const char *message, const char *linkname, double s) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         s);
  StopType = s;
}
void G1T(const char *message, const char *linkname, double t) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         t);
  JointTorque = t;
}
void G1I(const char *message, const char *linkname, double i) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         i);
  InvertRightSide = i;
}
void G1B(const char *message, const char *linkname, double b) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         b);
  InvertBackLegs = b;
  G1(ActiveLegs, FootXPos, FootYPos, FootZPos, JointSpeed, StopType, JointTorque, InvertRightSide, InvertBackLegs); 
}


//-------------------------------------------------------------------------//
//--------------------------------G2---------------------------------------//

//react GCode
void G2 () {
  //exicute motor movement 
  FRHip.spinToPosition(0, degrees, false); 
  FRThigh.spinToPosition(0, degrees, false); 
  FRKnee1.spinToPosition(0, degrees, false); 
  FRKnee2.spinToPosition(0, degrees, false); 
  BRHip.spinToPosition(0, degrees, false); 
  BRThigh.spinToPosition(0, degrees, false); 
  BRKnee1.spinToPosition(0, degrees, false); 
  BRKnee2.spinToPosition(0, degrees, false);
  
  /*
  //wait until movement is finished
  waitUntil(FRHip.isDone()&& FRThigh.isDone() && FRKnee1.isDone() && FRKnee2.isDone() && BRHip.isDone() && BRThigh.isDone() && BRKnee1.isDone() && BRKnee2.isDone());

  //send finished message
  LinkA.send("GCFinished");
  */
}
//read GCode
void G2_Recieved(const char *message, const char *linkname, double t) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         t);
  G2();
}


//-------------------------------------------------------------------------//
//--------------------------------G3---------------------------------------//




//-------------------------------------------------------------------------//
//--------------------------------G4---------------------------------------//

//react GCode
void HomeKnees () {
  //give motors torque
  FRKnee1.setMaxTorque(99, percent); 
  FRKnee2.setMaxTorque(99, percent);
  BRKnee1.setMaxTorque(99, percent); 
  BRKnee2.setMaxTorque(99, percent);
  FRHip.setMaxTorque(99, percent);
  BRHip.setMaxTorque(99, percent);
  FRThigh.setMaxTorque(99, percent);
  BRThigh.setMaxTorque(99, percent);

  // all knee axis home sequence:
  while (HomingLegCount == 1) {
    //print to terminal motor values 
    printMotorValues(true, false, false, false, false, false);

    //FRK
    if (FRKnee1.torque() <= FRKHomingPeakTorque || FRKnee2.torque() <= FRKHomingPeakTorque) {
      FRKnee1.setVelocity(KneeHomingVelocity, percent);
      FRKnee2.setVelocity(KneeHomingVelocity, percent);
      FRKnee1.spin(forward);
      FRKnee2.spin(forward);
    }
    //BRK
    if (BRKnee1.torque() <= BRKHomingPeakTorque || BRKnee2.torque() <= BRKHomingPeakTorque) {
      BRKnee1.setVelocity(KneeHomingVelocity, percent);
      BRKnee2.setVelocity(KneeHomingVelocity, percent);
      BRKnee1.spin(reverse);
      BRKnee2.spin(reverse);
    }
    if (((FRKnee1.torque() >= FRKHomingPeakTorque) && (FRKnee2.torque() >= FRKHomingPeakTorque)) && ((BRKnee1.torque() >= BRKHomingPeakTorque) && (BRKnee2.torque() >= BRKHomingPeakTorque))) {
      LinkA.send("RightHomeKneesFinished");
      HomingLegCount += 1;
    }
  }
}
void HomeLegs () {
  // frunt right and back right legs home:
  // frh and brh homed sequence:
  while (HomingLegCount == 2) {
    if (FRHip.torque() <= FRHHomingPeakTorque) {
      FRHip.setVelocity(HipHomingVelocity, percent);
      FRHip.spin(reverse);
    }
    if (BRHip.torque() <= BRHHomingPeakTorque) {
      BRHip.setVelocity(HipHomingVelocity, percent);
      BRHip.spin(reverse);
    }
    if (FRHip.torque() >= FRHHomingPeakTorque &&
        BRHip.torque() >= BRHHomingPeakTorque) {
      HomingLegCount += 1;

      // move to stand pos:
      FRKnee1.spinFor(reverse, 10 * KneeGearRatio, degrees, false);
      FRKnee2.spinFor(reverse, 10 * KneeGearRatio, degrees, false);
      BRKnee1.spinFor(forward, 10 * KneeGearRatio, degrees, false);
      BRKnee2.spinFor(forward, 10 * KneeGearRatio, degrees);
      FRHip.spinFor(forward, 5 * HipGearRatio, degrees, false);
      BRHip.spinFor(forward, 15 * HipGearRatio, degrees);
      wait(0.5, seconds);
    }
  }

  // frt and brt homed sequence:
  while (HomingLegCount == 3) {
    if (FRThigh.torque() <= FRTHomingPeakTorque) {
      FRThigh.setVelocity(ThighHomingVelocity, percent);
      FRThigh.spin(forward);
    }
    if (BRThigh.torque() <= BRTHomingPeakTorque) {
      BRThigh.setVelocity(ThighHomingVelocity, percent);
      BRThigh.spin(reverse);
    }
    if (FRThigh.torque() >= FRTHomingPeakTorque &&
        BRThigh.torque() >= BRTHomingPeakTorque) {
      HomingLegCount += 1;

      // move to stand pos:
      FRThigh.spinFor(reverse, 30 * ThighGearRatio, degrees, false);
      BRThigh.spinFor(forward, 30 * ThighGearRatio, degrees, false);
      FRKnee1.spinFor(reverse, 20 * KneeGearRatio, degrees, false);
      FRKnee2.spinFor(reverse, 20 * KneeGearRatio, degrees, false);
      BRKnee1.spinFor(forward, 20 * KneeGearRatio, degrees, false);
      BRKnee2.spinFor(forward, 20 * KneeGearRatio, degrees);
      FRHip.spinFor(forward, 95 * HipGearRatio, degrees, false);
      BRHip.spinFor(forward, 90 * HipGearRatio, degrees);
      FRKnee1.spinFor(reverse, 40 * KneeGearRatio, degrees, false);
      FRKnee2.spinFor(reverse, 40 * KneeGearRatio, degrees, false);
      BRKnee1.spinFor(forward, 40 * KneeGearRatio, degrees, false);
      BRKnee2.spinFor(forward, 40 * KneeGearRatio, degrees);
    }
  }

  if (HomingLegCount == 4) {
    // invert back legs
    BRKnee1.spinFor(forward, 180 * KneeGearRatio, degrees, false);
    BRKnee2.spinFor(forward, 180 * KneeGearRatio, degrees);
    HomingLegCount += 1;

    //set 0 pos
    SetAllZeros();

    //send completion message
    LinkA.send("GCFinished");
  }
}
//read GCode
//Knees
void G4HomeKnees(const char *message, const char *linkname, double t) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         t);
  HomingLegCount = 1;
  HomeKnees();
}
//Legs
void G4HomeLegs(const char *message, const char *linkname, double t) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         t);
  HomeLegs();
}


//-------------------------------------------------------------------------//
//--------------------------------G5---------------------------------------//

//react GCode
void G5 () {
  EStop();
}
//read GCode
void G5EStop(const char *message, const char *linkname, double t) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         t);
  JointTorque = t;
  G5();
}

//-------------------------------------------------------------------------//
//--------------------------------Stand------------------------------------//

//react
void Stand (int RCValue) {
    if (RCValue == false) { // stand
    // move to stand
    G1(9, 0, 0, Height, 50, 3, 100, 0, 0);
  } else if (RCValue == true) { // lie down
    // lie down
    G1(9, 0, 1, 5, 50, 3, 100, 0, 0);
    //G5();
  }
}
//read
void StandMode_Recieved(const char *message, const char *linkname, double data) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         data);
  Stand(data);
}

//-------------------------------------------------------------------------//
//-------------------------Stationary Movement-----------------------------//

//react
void StationaryMovement (int CTRLAxis1, int CTRLAxis2) {
  // calc leg limmits
  ts = T + S;

  MaxLegLoookLARReach = sqrt(((Height * Height) * -1) + (ts * ts));

  // limit to how far the legs can handle without breaking
  if (MaxLegLoookLARReach > HipBendLimmit) {
    MaxLegLoookLARReach = HipBendLimmit;
  }

  // LOOK LEFT AND RIGHT and UP AND DOWN
  if (CTRLAxis1 != 0 || CTRLAxis2 != 0) {

    // calc leg Height by using the joistic as a potentiometer
    LookUpAndDownControllerSetSitHeight =
        MaxLookUpAndDownLegSit +
        ((MaxLookUpAndDownLegReach - MaxLookUpAndDownLegSit) *
         ((CTRLAxis2 + 100) / 2) / 100);

    // calc the inverse for the opposite set of legs
    LookUpAndDownControllerSetReachHeight =
        MaxLookUpAndDownLegReach -
        ((MaxLookUpAndDownLegReach - MaxLookUpAndDownLegSit) *
         ((CTRLAxis2 + 100) / 2) / 100);

    // calc leg hip pos by using the joistic as a potentiometer
    LookLeftAndRightCtrlSetPos =
        (MaxLegLoookLARReach * CTRLAxis1) / 100;

    // calc the inverse for the opposite set of legs
    LookLeftAndRightCtrlSetPosINVERSE = LookLeftAndRightCtrlSetPos * -1;

    //send motor movment 
    //FL
    G1(1, 0, LookLeftAndRightCtrlSetPos + StandHipOffset, LookUpAndDownControllerSetSitHeight, LookSpeed, 3, 100, 0, 0);
    //FR
    G1(2, 0, LookLeftAndRightCtrlSetPosINVERSE + (StandHipOffset * -1), LookUpAndDownControllerSetSitHeight, LookSpeed, 3, 100, 0, 0);
    //BL
    G1(3, 0, LookLeftAndRightCtrlSetPosINVERSE + StandHipOffset, LookUpAndDownControllerSetReachHeight, LookSpeed, 3, 100, 0, 0);
    //BR
    G1(4, 0, LookLeftAndRightCtrlSetPos + StandHipOffset, LookUpAndDownControllerSetReachHeight, LookSpeed, 3, 100, 0, 0);
  } else if (CTRLAxis1 == 0 && CTRLAxis2 == 0) {
    // move to stand when joistick equals zero
    G1(9, 0, 0, Height, 50, 3, 100, 0, 0);
  }
}
//read
void StationaryMovementModeX1_Recieved(const char *message, const char *linkname, double data) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         data);
  CTRLAxis1INTRecieved = data;
}
void StationaryMovementModeX2_Recieved(const char *message, const char *linkname, double data) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         data);
  CTRLAxis2INTRecieved = data;
  StationaryMovement(CTRLAxis1INTRecieved, CTRLAxis2INTRecieved);
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  //set all zeros 
  SetAllZeros();

  // register callback LinkA
  //GCODE
  //G0
  LinkA.received("G0", G0Enable);

  //G1
  LinkA.received("G1L", G1L);
  LinkA.received("G1X", G1X);
  LinkA.received("G1Y", G1Y);
  LinkA.received("G1Z", G1Z);
  LinkA.received("G1V", G1V);
  LinkA.received("G1S", G1S);
  LinkA.received("G1T", G1T);
  LinkA.received("G1I", G1I);
  LinkA.received("G1B", G1B);

  //G2
  LinkA.received("G2", G2_Recieved);

  //G4
  LinkA.received("G4Knees", G4HomeKnees);
  LinkA.received("G4Legs", G4HomeLegs);

  //G5
  LinkA.received("G5", G5EStop);

  //RC MODES
  //stand/lie down
  LinkA.received("StandMode", StandMode_Recieved);

  //stationary movement
  LinkA.received("StationaryMovementModeX1", StationaryMovementModeX1_Recieved);
  LinkA.received("StationaryMovementModeX2", StationaryMovementModeX2_Recieved);


  // register callback LinkC
  //GCF
  //FL
  LinkC.received("FLLegFinished", FLLegFinished_Recieved);

  //BL
  LinkC.received("BLLegFinished", BLLegFinished_Recieved);

  while (1) {
    // show link status
    Brain.Screen.setFillColor(green); 
    Brain.Screen.drawRectangle(0, 0, 480, 240);
    Brain.Screen.setFillColor(black); 
    Brain.Screen.setFont(propXXL); 
    Brain.Screen.printAt(10, 50, true, "LinkA: %s",
                         LinkA.isLinked() ? "ok" : "--");

    Brain.Screen.printAt(10, 150, true, "LinkC: %s",
                         LinkC.isLinked() ? "ok" : "--");
          
    //failed connection EStop
    if (LinkA.isLinked() == false || LinkC.isLinked() == false) {
      EStop();
    }
               
    // Allow other tasks to run
    this_thread::sleep_for(50);
  }
}
