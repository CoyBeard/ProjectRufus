#include "vex.h"

using namespace vex;
using signature = vision::signature;
using code = vision::code;

// A global instance of brain used for printing to the V5 Brain screen
brain  Brain;

// VEXcode device constructors
motor FLHip = motor(PORT6, ratio36_1, true);
motor FLThigh = motor(PORT7, ratio18_1, true);
motor FLKnee1 = motor(PORT8, ratio18_1, true);
motor FLKnee2 = motor(PORT9, ratio18_1, true);
motor BLHip = motor(PORT11, ratio36_1, false);
motor BLThigh = motor(PORT12, ratio18_1, true);
motor BLKnee1 = motor(PORT13, ratio18_1, true);
motor BLKnee2 = motor(PORT14, ratio18_1, true);

// VEXcode generated functions



/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void vexcodeInit( void ) {
  // nothing to initialize
}