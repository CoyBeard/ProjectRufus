/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\Coy                                              */
/*    Created:      Thu Dec 24 2020                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// FLHip                motor         6               
// FLThigh              motor         7               
// FLKnee1              motor         8               
// FLKnee2              motor         9               
// BLHip                motor         11              
// BLThigh              motor         12              
// BLKnee1              motor         13              
// BLKnee2              motor         14              
// ---- END VEXCODE CONFIGURED DEVICES ----

/*----------------------------------------------------------------------------*/
/* Description: Example Worker VEXlink code */
/*----------------------------------------------------------------------------*/
#include "vex.h"

using namespace vex;

// Instance of message link class
//Manager Link
vex::message_link LinkB(PORT10, "vex_robotics_team_1234_B", linkType::worker, true);

//Union Link
vex::message_link LinkC(PORT20, "vex_robotics_team_1234_B", linkType::worker, true);

//GCode Vars
int ActiveLegs = 0;
double FootXPos = 0;
double FootYPos = 0;
double FootZPos = 0;
double JointSpeed = 0;
int StopType = 0;
double JointTorque = 0;
double InvertRightSide = 0;
double InvertBackLegs = 0;
int BLFinished = false;
int FLFinished = false;
int GCodeFinished = false;

//stationary movement vars
int CTRLAxis1INTRecieved = 0;
int CTRLAxis2INTRecieved = 0;

//home vars
int SetAllZerosCalculated = false;

//pos calcs vars
// Trig vars
double BackLeftHipDegree = 0; // Motor degree of the hip
double BackRightHipDegree = 0;
double FruntLeftHipDegree = 0;
double FruntRightHipDegree = 0;
double FruntRightThighDegree = 0; // Motor degree of the thigh
double BackLeftThighDegree = 0;
double BackRightThighDegree = 0;
double FruntLeftThighDegree = 0;
double FruntRightKneeDegree = 0; // Motor degree of the knee
double FruntLeftKneeDegree = 0;
double BackRightKneeDegree = 0;
double BackLeftKneeDegree = 0;
double T = 6;    // thigh length
double S = 7.5;  // shin length
double x = 0;    // distance between foot and hip
double F = 7.29; // offset triangle
double b = 0;    // inner hip angle (h)
double y = 0;    // imaginary tryangle hypotenuse (FruntRightue)
double lf = 0;   // l + F
double a = 0;    // angle a

// Controller vars
// STATIONARY MOVEMENT VARS
int Mode = 1;          // what mode Rufus is in
double LookSpeed = 30; // speed of looking

// Look left and right vars
double MaxLegLoookLARReach = 0;               // Set by algorithm, limits how far the legs will move in and out for safty reasons
double HipBendLimmit = 3;                     // in
double LookLeftAndRightCtrlSetPos = 0;        // use controller as potentiometer
double LookLeftAndRightCtrlSetPosINVERSE = 0; // inverse

// Look up and down
double MaxLookUpAndDownLegReach = 12;
double MaxLookUpAndDownLegSit = 7;
double LookUpAndDownControllerSetSitHeight = 0;
double LookUpAndDownControllerSetReachHeight = 0;

// Walk vars
double Height = 11;             // in
double StepClearanceHeight = 5; // in
double BackLeftStride = 0;      // in
double BackRightStride = 0;     // in
double FruntLeftStride = 0;     // in
double FruntRightStride = 0;    // in
double StrideAccuracy = 2;      // in
double MaxLegReach = 0;         // set by algorithm (in)
double ThighGearRatio = 5.5;    // gear ration of the hips
double KneeGearRatio = 5.5;     // gear ratio of the knees
double HipGearRatio = 5.5;      // gear ratio of the hips
double RdToDegree = 57.2958;    // multiplicant to convert radiant to degree
double ThighHomeOffset = 90;    // thigh home offset (degrees)
double KneeHomeOffset = 90;     // knee home offset (degrees)
double ts = 0;                  // thigh + shin length (in)
//double HipSwayAmount = -1;      // inches
//double HipSwayVelocity = 10;    // percent
//double HipVelocity = 20;        // percent
double LegLengthHips = 0;       // length of leg when hip is moved
double StandHipOffset = 0;      // pos-facing in-  or  neg-facing out-, controles if "pigeon toed" (in)
//int Estop = false;              // Emergency Stop
//int SetWalkDistance = 1000000;  // in
//int WalkDistance = 0;           // how far Rufus has wlalked

// Homing vars
int HomingLegCount = 1;       // Homing sequence counter
int HipHomingVelocity = 60;   // Hips Homing speed
int ThighHomingVelocity = 50; // Thighs Homing speed
int KneeHomingVelocity = 80;  // Knees Homing speed

// Sencorless homing Sensitivitys (Torque)
double FLKHomingPeakTorque = 0.4; // Nm
double BLKHomingPeakTorque = 0.4; // Hip Abs Max = 0.90 Nm
double FLTHomingPeakTorque = 0.6; // Thigh Abs Max = 0.91 Nm
double BLTHomingPeakTorque = 0.6; // Knee Abs Max = 1.81 Nm
double FLHHomingPeakTorque = 0.75;
double BLHHomingPeakTorque = 0.75;

void FLLegPos(double h, double l, double B) {
  T = 7;     // thigh length
  S = 5.375; // shin length
  x = 0;     // distance between foot and hip
  F = 7.29;  // offset triangle
  b = 0;     // inner hip angle (h)
  y = 0;     // imaginary tryangle hypotenuse (FruntRightue)
  lf = 0;    // l + F
  a = 0;     // a plus h = H

  // hip angle
  LegLengthHips = sqrt((B * B) + (h * h));

  FruntLeftHipDegree =
      (acos(((LegLengthHips * LegLengthHips) + (h * h) - (B * B)) /
            (2 * LegLengthHips * h))) *
      RdToDegree;

  if (B < 0) {
    FruntLeftHipDegree *= -1;
  }

  // leg angle
  x = sqrt((h * h) + (l * l));

  b = acos(((x * x) + (T * T) - (S * S)) / (2 * x * T));

  lf = l + F;

  y = sqrt(((h * h) + (lf * lf)));

  a = acos(((x * x) + (F * F) - (y * y)) / (2 * x * F));

  FruntLeftThighDegree =
      ((acos(((x * x) + (T * T) - (S * S)) / (2 * T * x))) + a) * RdToDegree *
      ThighGearRatio;

  FruntLeftKneeDegree = ((acos(((S * S) + (T * T) - (x * x)) / (2 * T * S))) *
                         RdToDegree * -1 * KneeGearRatio);

  FruntLeftThighDegree =
      FruntLeftThighDegree - (ThighHomeOffset * ThighGearRatio);

  FruntLeftKneeDegree = FruntLeftKneeDegree + (KneeHomeOffset * KneeGearRatio);

  FruntLeftHipDegree = FruntLeftHipDegree * ThighGearRatio;
}

void BLLegPos(double h, double l, double B) {
  T = 7;     // thigh length
  S = 5.375; // shin length
  x = 0;     // distance between foot and hip
  F = 7.29;  // offset triangle
  b = 0;     // inner hip angle (h)
  y = 0;     // imaginary tryangle hypotenuse (BackLeftue)
  lf = 0;    // l + F
  a = 0;     // a plus h = H

  // hip angle
  LegLengthHips = sqrt((B * B) + (h * h));

  BackLeftHipDegree =
      (acos(((LegLengthHips * LegLengthHips) + (h * h) - (B * B)) /
            (2 * LegLengthHips * h))) *
      RdToDegree;

  if (B < 0) {
    BackLeftHipDegree *= -1;
  }

  // leg angle
  x = sqrt((h * h) + (l * l));

  b = acos(((x * x) + (T * T) - (S * S)) / (2 * x * T));

  lf = l + F;

  y = sqrt(((h * h) + (lf * lf)));

  a = acos(((x * x) + (F * F) - (y * y)) / (2 * x * F));

  BackLeftThighDegree =
      ((acos(((x * x) + (T * T) - (S * S)) / (2 * T * x))) + a) * RdToDegree *
      ThighGearRatio;

  BackLeftKneeDegree = ((acos(((S * S) + (T * T) - (x * x)) / (2 * T * S))) *
                         RdToDegree * -1 * KneeGearRatio);

  BackLeftThighDegree =
      BackLeftThighDegree - (ThighHomeOffset * ThighGearRatio);

  BackLeftKneeDegree = BackLeftKneeDegree + (KneeHomeOffset * KneeGearRatio);

  BackLeftHipDegree = BackLeftHipDegree * ThighGearRatio;
}

void printMotorValues(int Temp, int Torque, int Power, int Current, int Voltage, int Position) {
  if (Temp == true) {
    printf("BackLeftE Motor Temp percent: %i\n", int(BLHip.temperature()));
    printf("FruntLeftE Motor Temp percent: %i\n", int(FLHip.temperature()));
    printf("BackLeftL Motor Temp percent: %i\n", int(BLThigh.temperature()));
    printf("FruntLeftL Motor Temp percent: %i\n", int(FLThigh.temperature()));
    printf("BackLeftK Motor Temp percent: %i\n", int(BLKnee1.temperature()));
    printf("FruntLeftK Motor Temp percent: %i\n", int(FLKnee1.temperature()));
  }
  if (Torque == true) {
    printf("BackLeftE Motor Torque Nm (*100): %i\n", int(100 * BLHip.torque()));
    printf("FruntLeftE Motor Torque Nm (*100): %i\n",
           int(100 * FLHip.torque()));
    printf("BackLeftL Motor Torque Nm (*100): %i\n",
           int(100 * BLThigh.torque()));
    printf("FruntLeftL Motor Torque Nm (*100): %i\n",
           int(100 * FLThigh.torque()));
    printf("BackLeftK Motor Torque Nm (*100): %i\n",
           int(100 * BLKnee1.torque()));
    printf("FruntLeftK Motor Torque Nm (*100): %i\n",
           int(100 * FLKnee1.torque()));
  }
  if (Power == true) {
    printf("BackLeftE Motor Power watts (*100): %i\n",
           int(100 * BLHip.power()));
    printf("FruntLeftE Motor Power watts (*100): %i\n",
           int(100 * FLHip.power()));
    printf("BackLeftL Motor Power watts (*100): %i\n",
           int(100 * BLThigh.power()));
    printf("FruntLeftL Motor Power watts (*100): %i\n",
           int(100 * FLThigh.power()));
    printf("BackLeftK Motor Power watts (*100): %i\n",
           int(100 * BLKnee1.power()));
    printf("FruntLeftK Motor Power watts (*100): %i\n",
           int(100 * FLKnee1.power()));
  }
  if (Current == true) {
    printf("BackLeftE Motor Current amps (*100): %i\n",
           int(100 * BLHip.current()));
    printf("FruntLeftE Motor Current amps (*100): %i\n",
           int(100 * FLHip.current()));
    printf("BackLeftL Motor Current amps (*100): %i\n",
           int(100 * BLThigh.current()));
    printf("FruntLeftL Motor Current amps (*100): %i\n",
           int(100 * FLThigh.current()));
    printf("BackLeftK Motor Current amps (*100): %i\n",
           int(100 * BLKnee1.current()));
    printf("FruntLeftK Motor Current amps (*100): %i\n",
           int(100 * FLKnee1.current()));
  }
  if (Voltage == true) {
    printf("BackLeftE Motor Volts (*100): %i\n",
           int(100 * BLHip.power() - BLHip.current()));
    printf("FruntLeftE Motor Volts (*100): %i\n",
           int(100 * FLHip.power() - FLHip.current()));
    printf("BackLeftL Motor Volts (*100): %i\n",
           int(100 * BLThigh.power() - BLThigh.current()));
    printf("FruntLeftL Motor Volts (*100): %i\n",
           int(100 * FLThigh.power() - FLThigh.current()));
    printf("BackLeftK Motor Volts (*100): %i\n",
           int(100 * BLKnee1.power() - BLKnee1.current()));
    printf("FruntLeftK Motor Volts (*100): %i\n",
           int(100 * FLKnee1.power() - FLKnee1.current()));
  }
  if (Position) {
    printf("BackLeftE Motor Position deg: %i\n", int(BLHip.position(degrees)));
    printf("FruntLeftE Motor Position deg: %i\n", int(FLHip.position(degrees)));
    printf("BackLeftL Motor Position deg: %i\n",
           int(BLThigh.position(degrees)));
    printf("FruntLeftL Motor Position deg: %i\n",
           int(FLThigh.position(degrees)));
    printf("BackLeftK Motor Position deg: %i\n", int(BLKnee1.position(degrees)));
    printf("FruntLeftK Motor Position deg: %i\n",
           int(FLKnee1.position(degrees)));

  }
}

void EStop () {
  FLHip.setVelocity(0, percent); 
  FLThigh.setVelocity(0, percent); 
  FLKnee1.setVelocity(0, percent); 
  FLKnee2.setVelocity(0, percent); 
  BLHip.setVelocity(0, percent); 
  BLThigh.setVelocity(0, percent); 
  BLKnee1.setVelocity(0, percent); 
  BLKnee2.setVelocity(0, percent); 
  FLHip.setMaxTorque(0, percent); 
  FLThigh.setMaxTorque(0, percent); 
  FLKnee1.setMaxTorque(0, percent); 
  FLKnee2.setMaxTorque(0, percent); 
  BLHip.setMaxTorque(0, percent); 
  BLThigh.setMaxTorque(0, percent); 
  BLKnee1.setMaxTorque(0, percent); 
  BLKnee2.setMaxTorque(0, percent); 
  BLHip.setStopping(coast);
  BLThigh.setStopping(coast);
  BLKnee1.setStopping(coast);
  BLKnee2.setStopping(coast);
  FLHip.setStopping(coast);
  FLThigh.setStopping(coast);
  FLKnee1.setStopping(coast);
  FLKnee2.setStopping(coast);
  FLHip.spinTo(0,degrees, false); 
  FLThigh.spinTo(0,degrees, false); 
  FLKnee1.spinTo(0,degrees, false); 
  FLKnee2.spinTo(0,degrees, false); 
  BLHip.spinTo(0,degrees, false); 
  BLThigh.spinTo(0,degrees, false); 
  BLKnee1.spinTo(0,degrees, false); 
  BLKnee2.spinTo(0,degrees, false);
  FLHip.stop(); 
  FLThigh.stop(); 
  FLKnee1.stop(); 
  FLKnee2.stop(); 
  BLHip.stop(); 
  BLThigh.stop(); 
  BLKnee1.stop(); 
  BLKnee2.stop();
  LinkB.send("GCFinished");
}

void SetAllZeros() {
  if (SetAllZerosCalculated == false) {
    BLHip.setPosition(0, degrees); 
    BLThigh.setPosition(0, degrees); 
    BLKnee1.setPosition(0, degrees); 
    BLKnee2.setPosition(0, degrees); 
    FLHip.setPosition(0, degrees); 
    FLThigh.setPosition(0, degrees); 
    FLKnee1.setPosition(0, degrees); 
    FLKnee2.setPosition(0, degrees); 
    SetAllZerosCalculated = true;
  }
}

//-------------------------------------------------------------------------//
//--------------------------------G0---------------------------------------//

//react GCode
void G0 () {
  //set velocity
    FLHip.setVelocity(100, percent); 
    FLThigh.setVelocity(100, percent); 
    FLKnee1.setVelocity(100, percent); 
    FLKnee2.setVelocity(100, percent); 
    BLHip.setVelocity(100, percent); 
    BLThigh.setVelocity(100, percent); 
    BLKnee1.setVelocity(100, percent); 
    BLKnee2.setVelocity(100, percent); 

    //set torque
    FLHip.setMaxTorque(100, percent); 
    FLThigh.setMaxTorque(100, percent); 
    FLKnee1.setMaxTorque(100, percent); 
    FLKnee2.setMaxTorque(100, percent); 
    BLHip.setMaxTorque(100, percent); 
    BLThigh.setMaxTorque(100, percent); 
    BLKnee1.setMaxTorque(100, percent); 
    BLKnee2.setMaxTorque(100, percent); 

    //set brake
    FLHip.setStopping(hold); 
    FLThigh.setStopping(hold); 
    FLKnee1.setStopping(hold); 
    FLKnee2.setStopping(hold); 
    BLHip.setStopping(hold); 
    BLThigh.setStopping(hold); 
    BLKnee1.setStopping(hold); 
    BLKnee2.setStopping(hold); 

    //exicute motor movement 
    FLHip.spinFor(1, degrees, false); 
    FLThigh.spinFor(1, degrees, false); 
    FLKnee1.spinFor(1, degrees, false); 
    FLKnee2.spinFor(1, degrees, false); 
    BLHip.spinFor(1, degrees, false); 
    BLThigh.spinFor(1, degrees, false); 
    BLKnee1.spinFor(1, degrees, false); 
    BLKnee2.spinFor(1, degrees, false);

    //feedback
    LinkB.send("LeftMotorsEnabled");
}
//read GCode
void G0Enable(const char *message, const char *linkname, double t) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         t);
  G0();
}

//-------------------------------------------------------------------------//
//--------------------------------G1---------------------------------------//

//react GCode
void G1(int l, double x, double y, double z, double v, int s, double t, int i, int b) {
  if (l == 1 || l == 5 || l == 7 || l == 9|| l == 10) {// FL
    //set velocity
    FLHip.setVelocity(v, percent); 
    FLThigh.setVelocity(v, percent); 
    FLKnee1.setVelocity(v, percent); 
    FLKnee2.setVelocity(v, percent); 

    //set torque
    FLHip.setMaxTorque(t, percent); 
    FLThigh.setMaxTorque(t, percent); 
    FLKnee1.setMaxTorque(t, percent); 
    FLKnee2.setMaxTorque(t, percent); 

    //set stopping type
    if (s == 1) {
      FLHip.setStopping(brake); 
      FLThigh.setStopping(brake); 
      FLKnee1.setStopping(brake); 
      FLKnee2.setStopping(brake); 
    }
    if (s == 2) {
      FLHip.setStopping(coast); 
      FLThigh.setStopping(coast); 
      FLKnee1.setStopping(coast); 
      FLKnee2.setStopping(coast); 
    }
    if (s == 3) {
      FLHip.setStopping(hold); 
      FLThigh.setStopping(hold); 
      FLKnee1.setStopping(hold); 
      FLKnee2.setStopping(hold); 
    }

    //calc motor degrees
    FLLegPos(z, x, y);
    
    //exicute motor movement 
    FLHip.spinToPosition(FruntLeftHipDegree, degrees, false); 
    FLThigh.spinToPosition(FruntLeftThighDegree, degrees, false); 
    FLKnee1.spinToPosition(FruntLeftKneeDegree, degrees, false); 
    FLKnee2.spinToPosition(FruntLeftKneeDegree, degrees, false); 

    /*
    //send GCF cases
    if (l == 1) {
      //send finished message
      waitUntil(FLHip.isDone() && FLThigh.isDone() && FLKnee1.isDone() && FLKnee2.isDone());
      LinkB.send("GCFinished");
    } 

    //send leg finished cases 
    if (l == 5 || l == 10) {
      //send finished message
      waitUntil(FLHip.isDone() && FLThigh.isDone() && FLKnee1.isDone() && FLKnee2.isDone());
      LinkC.send("FLLegFinished");
    }
    */
  }

  if (l == 3 || l == 6 || l == 7 || l == 9 || l == 11) {// BL
    //set velocity
    BLHip.setVelocity(v, percent); 
    BLThigh.setVelocity(v, percent); 
    BLKnee1.setVelocity(v, percent); 
    BLKnee2.setVelocity(v, percent); 

    //set torque
    BLHip.setMaxTorque(t, percent); 
    BLThigh.setMaxTorque(t, percent); 
    BLKnee1.setMaxTorque(t, percent); 
    BLKnee2.setMaxTorque(t, percent); 

    //set stopping type
    if (s == 1) {
      BLHip.setStopping(brake); 
      BLThigh.setStopping(brake); 
      BLKnee1.setStopping(brake); 
      BLKnee2.setStopping(brake); 
    }
    if (s == 2) {
      BLHip.setStopping(coast); 
      BLThigh.setStopping(coast); 
      BLKnee1.setStopping(coast); 
      BLKnee2.setStopping(coast); 
    }
    if (s == 3) {
      BLHip.setStopping(hold); 
      BLThigh.setStopping(hold); 
      BLKnee1.setStopping(hold); 
      BLKnee2.setStopping(hold); 
    }

    //calc motor degrees
    if (b == 0) {
      BLLegPos(z, x, y);
    }
    if (b == 1) {
      BLLegPos(z, (x * -1), y);
    }
    
    //exicute motor movement 
    BLHip.spinToPosition(BackLeftHipDegree, degrees, false); 
    BLThigh.spinToPosition(BackLeftThighDegree, degrees, false); 
    BLKnee1.spinToPosition(BackLeftKneeDegree, degrees, false); 
    BLKnee2.spinToPosition(BackLeftKneeDegree, degrees, false);

    /*
    //send GCF cases
    if (l == 3) {
      //send finished message
      waitUntil(BLHip.isDone() && BLThigh.isDone() && BLKnee1.isDone() && BLKnee2.isDone());
      LinkB.send("GCFinished");
    }
    if (l == 7) {
      //send finished message
      waitUntil(BLHip.isDone() && BLThigh.isDone() && BLKnee1.isDone() && BLKnee2.isDone() && FLHip.isDone() && FLThigh.isDone() && FLKnee1.isDone() && FLKnee2.isDone());
      LinkB.send("GCFinished");
    } 

    //send Leg finished cases 
    if (l == 6 || l == 11) {
      //send finished message
      waitUntil(BLHip.isDone() && BLThigh.isDone() && BLKnee1.isDone() && BLKnee2.isDone());
      LinkC.send("BLLegFinished");
    }
    if (l == 9) {
      //send finished message
      waitUntil(BLHip.isDone() && BLThigh.isDone() && BLKnee1.isDone() && BLKnee2.isDone() && FLHip.isDone() && FLThigh.isDone() && FLKnee1.isDone() && FLKnee2.isDone());
      LinkC.send("FLLegFinished");
      LinkC.send("BLLegFinished");
    }
    */
  }
}
//read GCode
void G1L(const char *message, const char *linkname, double l) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         l);
  ActiveLegs = l;
}
void G1X(const char *message, const char *linkname, double x) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         x);
  FootXPos = x;
}
void G1Y(const char *message, const char *linkname, double y) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         y);
  FootYPos = y;
}
void G1Z(const char *message, const char *linkname, double z) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         z);
  FootZPos = z;
}
void G1V(const char *message, const char *linkname, double v) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         v);
  JointSpeed = v;
}
void G1S(const char *message, const char *linkname, double s) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         s);
  StopType = s;
}
void G1T(const char *message, const char *linkname, double t) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         t);
  JointTorque = t;
}
void G1I(const char *message, const char *linkname, double i) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         i);
  InvertRightSide = i;
}
void G1B(const char *message, const char *linkname, double b) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         b);
  InvertBackLegs = b;
  G1(ActiveLegs, FootXPos, FootYPos, FootZPos, JointSpeed, StopType, JointTorque, InvertRightSide, InvertBackLegs); 
}


//-------------------------------------------------------------------------//
//--------------------------------G2---------------------------------------//

//react GCode
void G2 () {
  //exicute motor movement 
  FLHip.spinToPosition(0, degrees, false); 
  FLThigh.spinToPosition(0, degrees, false); 
  FLKnee1.spinToPosition(0, degrees, false); 
  FLKnee2.spinToPosition(0, degrees, false); 
  BLHip.spinToPosition(0, degrees, false); 
  BLThigh.spinToPosition(0, degrees, false); 
  BLKnee1.spinToPosition(0, degrees, false); 
  BLKnee2.spinToPosition(0, degrees, false);
  
  /*
  //wait until movement is finished
  waitUntil(FLHip.isDone()&& FLThigh.isDone() && FLKnee1.isDone() && FLKnee2.isDone() && BLHip.isDone() && BLThigh.isDone() && BLKnee1.isDone() && BLKnee2.isDone());

  //send finished message
  LinkB.send("GCFinished");
  */
}
//read GCode
void G2_Recieved(const char *message, const char *linkname, double t) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         t);
  G2();
}


//-------------------------------------------------------------------------//
//--------------------------------G3---------------------------------------//




//-------------------------------------------------------------------------//
//--------------------------------G4---------------------------------------//

//react GCode
void HomeKnees () {
  //give motors torque
  FLKnee1.setMaxTorque(99, percent); 
  FLKnee2.setMaxTorque(99, percent);
  BLKnee1.setMaxTorque(99, percent); 
  BLKnee2.setMaxTorque(99, percent);
  FLHip.setMaxTorque(99, percent);
  BLHip.setMaxTorque(99, percent);
  FLThigh.setMaxTorque(99, percent);
  BLThigh.setMaxTorque(99, percent);

  // all knee axis home sequence:
  while (HomingLegCount == 1) {
    //print to terminal motor values 
    printMotorValues(true, false, false, false, false, false);

    //FLK
    if (FLKnee1.torque() <= FLKHomingPeakTorque || FLKnee2.torque() <= FLKHomingPeakTorque) {
      FLKnee1.setVelocity(KneeHomingVelocity, percent);
      FLKnee2.setVelocity(KneeHomingVelocity, percent);
      FLKnee1.spin(forward);
      FLKnee2.spin(forward);
    }
    //BLK
    if (BLKnee1.torque() <= BLKHomingPeakTorque || BLKnee2.torque() <= BLKHomingPeakTorque) {
      BLKnee1.setVelocity(KneeHomingVelocity, percent);
      BLKnee2.setVelocity(KneeHomingVelocity, percent);
      BLKnee1.spin(reverse);
      BLKnee2.spin(reverse);
    }
    if (((FLKnee1.torque() >= FLKHomingPeakTorque) && (FLKnee2.torque() >= FLKHomingPeakTorque)) && ((BLKnee1.torque() >= BLKHomingPeakTorque) && (BLKnee2.torque() >= BLKHomingPeakTorque))) {
      LinkB.send("LeftHomeKneesFinished");
      HomingLegCount += 1;
    }
  }
}
void HomeLegs () {
  // frunt left and back left legs home:
  // flh and brh homed sequence:
  while (HomingLegCount == 2) {
    if (FLHip.torque() <= FLHHomingPeakTorque) {
      FLHip.setVelocity(HipHomingVelocity, percent);
      FLHip.spin(reverse);
    }
    if (BLHip.torque() <= BLHHomingPeakTorque) {
      BLHip.setVelocity(HipHomingVelocity, percent);
      BLHip.spin(reverse);
    }
    if (FLHip.torque() >= FLHHomingPeakTorque &&
        BLHip.torque() >= BLHHomingPeakTorque) {
      HomingLegCount += 1;

      // move to stand pos:
      FLKnee1.spinFor(reverse, 10 * KneeGearRatio, degrees, false);
      FLKnee2.spinFor(reverse, 10 * KneeGearRatio, degrees, false);
      BLKnee1.spinFor(forward, 10 * KneeGearRatio, degrees, false);
      BLKnee2.spinFor(forward, 10 * KneeGearRatio, degrees);
      FLHip.spinFor(forward, 5 * HipGearRatio, degrees, false);
      BLHip.spinFor(forward, 15 * HipGearRatio, degrees);
      wait(0.5, seconds);
    }
  }

  // flt and brt homed sequence:
  while (HomingLegCount == 3) {
    if (FLThigh.torque() <= FLTHomingPeakTorque) {
      FLThigh.setVelocity(ThighHomingVelocity, percent);
      FLThigh.spin(forward);
    }
    if (BLThigh.torque() <= BLTHomingPeakTorque) {
      BLThigh.setVelocity(ThighHomingVelocity, percent);
      BLThigh.spin(reverse);
    }
    if (FLThigh.torque() >= FLTHomingPeakTorque &&
        BLThigh.torque() >= BLTHomingPeakTorque) {
      HomingLegCount += 1;

      // move to stand pos:
      FLThigh.spinFor(reverse, 15 * ThighGearRatio, degrees, false);
      BLThigh.spinFor(forward, 30 * ThighGearRatio, degrees, false);
      FLKnee1.spinFor(reverse, 20 * KneeGearRatio, degrees, false);
      FLKnee2.spinFor(reverse, 20 * KneeGearRatio, degrees, false);
      BLKnee1.spinFor(forward, 20 * KneeGearRatio, degrees, false);
      BLKnee2.spinFor(forward, 20 * KneeGearRatio, degrees);
      FLHip.spinFor(forward, 95 * HipGearRatio, degrees, false);
      BLHip.spinFor(forward, 90 * HipGearRatio, degrees);
      FLKnee1.spinFor(reverse, 40 * KneeGearRatio, degrees, false);
      FLKnee2.spinFor(reverse, 40 * KneeGearRatio, degrees, false);
      BLKnee1.spinFor(forward, 40 * KneeGearRatio, degrees, false);
      BLKnee2.spinFor(forward, 40 * KneeGearRatio, degrees);
    }
  }

  if (HomingLegCount == 4) {
    //send completion message
    LinkB.send("LeftHomeLegsFinished");

    // invert back legs
    BLKnee1.spinFor(forward, 180 * KneeGearRatio, degrees, false);
    BLKnee2.spinFor(forward, 180 * KneeGearRatio, degrees);
    HomingLegCount += 1;

    //set 0 pos
    SetAllZeros();
  }
}
//read GCode
//Knees
void G4HomeKnees(const char *message, const char *linkname, double t) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         t);
  HomingLegCount = 1;
  HomeKnees();
}
//Legs
void G4HomeLegs(const char *message, const char *linkname, double t) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         t);
  HomeLegs();
}

//-------------------------------------------------------------------------//
//--------------------------------G5---------------------------------------//

//react GCode
void G5 () {
  EStop();
}
//read GCode
void G5EStop(const char *message, const char *linkname, double t) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         t);
  G5();
}

//-------------------------------------------------------------------------//
//--------------------------------Stand------------------------------------//

//react
void Stand (int RCValue) {
  if (RCValue == false) { // stand
    // move to stand
    G1(9, 0, 0, Height, 50, 3, 100, 0, 0);
  } else if (RCValue == true) { // lie down
    // lie down
    G1(9, 0, 1, 5, 50, 3, 100, 0, 0);
    //G5();
  }
}
//read
void StandMode_Recieved(const char *message, const char *linkname, double data) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         data);
  Stand(data);
}

//-------------------------------------------------------------------------//
//-------------------------Stationary Movement-----------------------------//

//react
void StationaryMovement (int CTRLAxis1, int CTRLAxis2) {
  // calc leg limmits
  ts = T + S;

  MaxLegLoookLARReach = sqrt(((Height * Height) * -1) + (ts * ts));

  // limit to how far the legs can handle without breaking
  if (MaxLegLoookLARReach > HipBendLimmit) {
    MaxLegLoookLARReach = HipBendLimmit;
  }

  // LOOK LEFT AND RIGHT and UP AND DOWN
  if (CTRLAxis1 != 0 || CTRLAxis2 != 0) {

    // calc leg Height by using the joistic as a potentiometer
    LookUpAndDownControllerSetSitHeight =
        MaxLookUpAndDownLegSit +
        ((MaxLookUpAndDownLegReach - MaxLookUpAndDownLegSit) *
         ((CTRLAxis2 + 100) / 2) / 100);

    // calc the inverse for the opposite set of legs
    LookUpAndDownControllerSetReachHeight =
        MaxLookUpAndDownLegReach -
        ((MaxLookUpAndDownLegReach - MaxLookUpAndDownLegSit) *
         ((CTRLAxis2 + 100) / 2) / 100);

    // calc leg hip pos by using the joistic as a potentiometer
    LookLeftAndRightCtrlSetPos =
        (MaxLegLoookLARReach * CTRLAxis1) / 100;

    // calc the inverse for the opposite set of legs
    LookLeftAndRightCtrlSetPosINVERSE = LookLeftAndRightCtrlSetPos * -1;

    //send motor movment 
    //FL
    G1(1, 0, LookLeftAndRightCtrlSetPos + StandHipOffset, LookUpAndDownControllerSetSitHeight, LookSpeed, 3, 100, 0, 0);
    //FR
    G1(2, 0, LookLeftAndRightCtrlSetPosINVERSE + (StandHipOffset * -1), LookUpAndDownControllerSetSitHeight, LookSpeed, 3, 100, 0, 0);
    //BL
    G1(3, 0, LookLeftAndRightCtrlSetPosINVERSE + StandHipOffset, LookUpAndDownControllerSetReachHeight, LookSpeed, 3, 100, 0, 0);
    //BR
    G1(4, 0, LookLeftAndRightCtrlSetPos + StandHipOffset, LookUpAndDownControllerSetReachHeight, LookSpeed, 3, 100, 0, 0);
  } else if (CTRLAxis1 == 0 && CTRLAxis2 == 0) {
    // move to stand when joistick equals zero
    G1(9, 0, 0, Height, 50, 3, 100, 0, 0);
  }
}
//read
void StationaryMovementModeX1_Recieved(const char *message, const char *linkname, double data) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         data);
  CTRLAxis1INTRecieved = data;
}
void StationaryMovementModeX2_Recieved(const char *message, const char *linkname, double data) {
  printf("%s: was received on '%s' link with value %.2f\n", message, linkname,
         data);
  CTRLAxis2INTRecieved = data;
  StationaryMovement(CTRLAxis1INTRecieved, CTRLAxis2INTRecieved);
}

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

  //set all zeros 
  SetAllZeros();

  // register callback
  //G0
  LinkB.received("G0", G0Enable);

  //G1
  LinkB.received("G1L", G1L);
  LinkB.received("G1X", G1X);
  LinkB.received("G1Y", G1Y);
  LinkB.received("G1Z", G1Z);
  LinkB.received("G1V", G1V);
  LinkB.received("G1S", G1S);
  LinkB.received("G1T", G1T);
  LinkB.received("G1I", G1I);
  LinkB.received("G1B", G1B);

  //G2
  LinkB.received("G2", G2_Recieved);

  //G4
  LinkB.received("G4Knees", G4HomeKnees);
  LinkB.received("G4Legs", G4HomeLegs);

  //G5
  LinkB.received("G5", G5EStop);

  //RC MODES
  //stand/lie down
  LinkB.received("StandMode", StandMode_Recieved);

  //stationary movement
  LinkB.received("StationaryMovementModeX1", StationaryMovementModeX1_Recieved);
  LinkB.received("StationaryMovementModeX2", StationaryMovementModeX2_Recieved);

  while (1) {
      //show link status
      Brain.Screen.setFillColor(green); 
      Brain.Screen.drawRectangle(0, 0, 480, 240);
      Brain.Screen.setFillColor(black); 
      Brain.Screen.setFont(propXXL); 
      Brain.Screen.printAt(10, 50, true, "LinkB: %s",
                         LinkB.isLinked() ? "ok" : "--");

      Brain.Screen.printAt(10, 150, true, "LinkC: %s",
                         LinkC.isLinked() ? "ok" : "--");
    
    //failed connection EStop
    if (LinkB.isLinked() == false || LinkC.isLinked() == false) {
      EStop();
    }

    // Allow other tasks to run
    this_thread::sleep_for(50);
  }
}
