using namespace vex;

extern brain Brain;

// VEXcode devices
extern motor FLHip;
extern motor FLThigh;
extern motor FLKnee1;
extern motor FLKnee2;
extern motor BLHip;
extern motor BLThigh;
extern motor BLKnee1;
extern motor BLKnee2;

/**
 * Used to initialize code/tasks/devices added using tools in VEXcode Pro.
 * 
 * This should be called at the start of your int main function.
 */
void  vexcodeInit( void );